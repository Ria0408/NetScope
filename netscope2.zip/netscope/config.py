"""Central paths and logging setup for NetScope."""
from __future__ import annotations

import logging
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
UPLOAD_DIR = DATA_DIR / "uploaded_datasets"
TRACE_DIR = DATA_DIR / "traces"
RESULTS_DIR = DATA_DIR / "results"
SIMULATION_DIR = PROJECT_ROOT / "simulation"
ANALYSIS_DIR = PROJECT_ROOT / "analysis"

_LOG_FORMAT = (
    "%(asctime)s | %(levelname)-7s | %(threadName)-18s | %(name)s | %(message)s"
)


def ensure_dirs() -> None:
    """Create the data directories if they do not exist."""
    for directory in (UPLOAD_DIR, TRACE_DIR, RESULTS_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def setup_logging(level: int = logging.INFO) -> None:
    """Configure console + file logging once per process."""
    root = logging.getLogger()
    if getattr(root, "_netscope_configured", False):
        return
    ensure_dirs()
    root.setLevel(level)
    handlers = (
        logging.StreamHandler(),
        logging.FileHandler(DATA_DIR / "netscope.log", encoding="utf-8"),
    )
    for handler in handlers:
        handler.setFormatter(logging.Formatter(_LOG_FORMAT))
        root.addHandler(handler)
    root._netscope_configured = True  # type: ignore[attr-defined]
