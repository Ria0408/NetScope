"""Thread-safe traffic statistics plus DataFrame helpers."""
from __future__ import annotations

import threading
from collections import Counter
from typing import Any, Dict, Iterable, List, Optional

import pandas as pd

from analysis import metrics
from capture.packet_parser import RECORD_COLUMNS

_SIZE_BIN = 100
_SIZE_BINS = 16  # 0-99 ... 1400-1499, 1500+


class TrafficStats:
    """Aggregates statistics from packet records.

    Every mutation and every snapshot happens while holding ``self._lock``
    (a ``threading.Lock``), so the statistics thread can update the counters
    while the dashboard thread reads them without races.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._reset()

    def _reset(self) -> None:
        self._total_packets = 0
        self._total_bytes = 0
        self._protocol_counts: Counter = Counter()
        self._protocol_bytes: Counter = Counter()
        self._src_counts: Counter = Counter()
        self._dst_counts: Counter = Counter()
        self._size_bins: Counter = Counter()
        self._second_packets: Counter = Counter()
        self._second_bytes: Counter = Counter()
        self._first_ts: Optional[float] = None
        self._last_ts: Optional[float] = None

    def reset(self) -> None:
        with self._lock:
            self._reset()

    def update(self, record: Dict[str, Any]) -> None:
        length = int(record["length"])
        ts = float(record["timestamp"])
        proto = record["protocol"]
        with self._lock:
            self._total_packets += 1
            self._total_bytes += length
            self._protocol_counts[proto] += 1
            self._protocol_bytes[proto] += length
            if record.get("src_ip"):
                self._src_counts[record["src_ip"]] += 1
            if record.get("dst_ip"):
                self._dst_counts[record["dst_ip"]] += 1
            self._size_bins[min(length // _SIZE_BIN, _SIZE_BINS - 1)] += 1
            second = int(ts)
            self._second_packets[second] += 1
            self._second_bytes[second] += length
            if self._first_ts is None or ts < self._first_ts:
                self._first_ts = ts
            if self._last_ts is None or ts > self._last_ts:
                self._last_ts = ts

    def snapshot(self, top_n: int = 10) -> Dict[str, Any]:
        """Consistent copy of all statistics (safe to use from any thread)."""
        with self._lock:
            base = metrics.dataset_metrics(
                self._total_packets, self._total_bytes, self._first_ts, self._last_ts
            )
            size_hist = [
                {
                    "range": (f"{i * _SIZE_BIN}-{i * _SIZE_BIN + _SIZE_BIN - 1}"
                              if i < _SIZE_BINS - 1 else f"{i * _SIZE_BIN}+"),
                    "packets": self._size_bins.get(i, 0),
                }
                for i in range(_SIZE_BINS)
            ]
            timeline: List[Dict[str, int]] = []
            if self._second_packets:
                start = min(self._second_packets)
                end = max(self._second_packets)
                for sec in range(start, end + 1):
                    timeline.append({
                        "second": sec - start,
                        "packets": self._second_packets.get(sec, 0),
                        "bytes": self._second_bytes.get(sec, 0),
                    })
            base.update({
                "first_timestamp": self._first_ts,
                "last_timestamp": self._last_ts,
                "protocol_counts": dict(self._protocol_counts),
                "protocol_bytes": dict(self._protocol_bytes),
                "top_sources": self._src_counts.most_common(top_n),
                "top_destinations": self._dst_counts.most_common(top_n),
                "unique_sources": len(self._src_counts),
                "unique_destinations": len(self._dst_counts),
                "size_histogram": size_hist,
                "timeline": timeline,
            })
            return base


def build_dataframe(records: Iterable[Dict[str, Any]]) -> pd.DataFrame:
    """Convert packet records into a typed DataFrame."""
    records = list(records)
    if not records:
        return pd.DataFrame(columns=RECORD_COLUMNS + ["relative_time"])
    df = pd.DataFrame.from_records(records, columns=RECORD_COLUMNS)
    for col in ("src_port", "dst_port"):
        df[col] = pd.to_numeric(df[col]).astype("Int64")
    df["relative_time"] = df["timestamp"] - df["timestamp"].min()
    return df


def apply_filters(
    df: pd.DataFrame,
    protocols: Optional[List[str]] = None,
    src_ip: str = "",
    dst_ip: str = "",
    port: Optional[int] = None,
) -> pd.DataFrame:
    """Filter packets by protocol, source IP, destination IP and port."""
    mask = pd.Series(True, index=df.index)
    if protocols:
        mask &= df["protocol"].isin(protocols)
    if src_ip.strip():
        mask &= df["src_ip"].fillna("").str.contains(src_ip.strip(), regex=False)
    if dst_ip.strip():
        mask &= df["dst_ip"].fillna("").str.contains(dst_ip.strip(), regex=False)
    if port is not None:
        port_hit = (df["src_port"] == port) | (df["dst_port"] == port)
        mask &= port_hit.fillna(False).astype(bool)
    return df[mask]
