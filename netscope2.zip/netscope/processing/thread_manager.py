"""Three-thread producer/consumer pipeline for packet analysis.

    +-------------+  raw_queue   +----------------+  parsed_queue  +--------------+
    | Thread 1    | -----------> | Thread 2       | -------------> | Thread 3     |
    | Reader      |  (number,    | Packet         |   record dict  | Statistics   |
    | (producer)  |   packet)    | Processing     |                | (consumer)   |
    +-------------+              +----------------+                +--------------+

Thread responsibilities
-----------------------
* ``netscope-reader``    Streams packets from the PCAP/PCAPNG file with Scapy's
  PcapReader and pushes ``(number, packet)`` into ``raw_queue``.
* ``netscope-processor`` Takes packets from ``raw_queue``, extracts IPs, ports,
  protocol, size and TCP flags, classifies the packet and pushes the record
  into ``parsed_queue``.
* ``netscope-stats``     Takes records from ``parsed_queue``, updates the
  shared ``TrafficStats`` (packet counts, bytes, protocol distribution,
  top talkers, size histogram, timeline) and stores records for the table.

Synchronization
---------------
* ``queue.Queue`` (wrapped by ``PacketQueue``) is internally locked, so passing
  data between threads needs no extra locking. Bounded size gives back-pressure.
* ``threading.Lock`` ``_lock``          guards counters, status and error list.
* ``threading.Lock`` ``_records_lock``  guards the stored record list.
* ``TrafficStats`` owns its own ``threading.Lock``; both updates and snapshots
  run under it, so the dashboard can read while the stats thread writes.
* ``threading.Event`` ``stop_event``    cooperative cancellation: every blocking
  queue call polls it, so all threads exit promptly.
* ``threading.Event`` ``finished_event`` set by the last thread to exit.
* Termination: the reader sends the ``END`` sentinel; each stage forwards it
  downstream, so every queued packet is processed before threads exit.
"""
from __future__ import annotations

import logging
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from capture.dataset_reader import iter_packets
from capture.packet_parser import parse_packet
from processing.analytics import TrafficStats, build_dataframe
from processing.packet_queue import END, PacketQueue

logger = logging.getLogger(__name__)

STATUS_IDLE = "idle"
STATUS_RUNNING = "running"
STATUS_COMPLETED = "completed"
STATUS_STOPPED = "stopped"
STATUS_FAILED = "failed"


class AnalysisPipeline:
    THREAD_NAMES = ("netscope-reader", "netscope-processor", "netscope-stats")

    def __init__(
        self,
        path: Union[str, Path],
        queue_size: int = 1000,
        max_records: int = 200_000,
        parse_fn: Callable[[Any, int], Dict[str, Any]] = parse_packet,
        reader_fn: Callable[[Union[str, Path]], Any] = iter_packets,
        stats: Optional[TrafficStats] = None,
    ) -> None:
        self.path = Path(path)
        self.max_records = max_records
        self._parse_fn = parse_fn
        self._reader_fn = reader_fn

        self.stop_event = threading.Event()
        self.finished_event = threading.Event()
        self.raw_queue = PacketQueue(queue_size, self.stop_event, name="raw")
        self.parsed_queue = PacketQueue(queue_size, self.stop_event, name="parsed")
        self.stats = stats if stats is not None else TrafficStats()

        self._lock = threading.Lock()
        self._records_lock = threading.Lock()
        self._records: List[Dict[str, Any]] = []
        self._truncated = False
        self._counts = {"read": 0, "parsed": 0, "stored": 0, "malformed": 0}
        self._errors: List[str] = []
        self._status = STATUS_IDLE
        self._stop_requested = False
        self._alive = 0
        self._threads: List[threading.Thread] = []
        self._started_at = 0.0
        self._elapsed = 0.0

    # ------------------------------------------------------------------ control
    def start(self) -> "AnalysisPipeline":
        with self._lock:
            if self._status == STATUS_RUNNING:
                raise RuntimeError("Pipeline is already running")
            self._status = STATUS_RUNNING
            self._alive = len(self.THREAD_NAMES)
        targets = (self._reader_loop, self._processor_loop, self._stats_loop)
        self._threads = [
            threading.Thread(target=target, name=name, daemon=True)
            for target, name in zip(targets, self.THREAD_NAMES)
        ]
        self._started_at = time.perf_counter()
        logger.info("Starting analysis of %s", self.path.name)
        for thread in self._threads:
            thread.start()
        return self

    def stop(self) -> None:
        """Request graceful cancellation."""
        with self._lock:
            self._stop_requested = True
        self.stop_event.set()

    def join(self, timeout: Optional[float] = None) -> bool:
        """Wait for completion. Returns True when all threads have finished."""
        finished = self.finished_event.wait(timeout)
        if finished:
            for thread in self._threads:
                thread.join(timeout=1.0)
        return finished

    def is_running(self) -> bool:
        with self._lock:
            return self._status == STATUS_RUNNING

    # --------------------------------------------------------------- thread bodies
    def _reader_loop(self) -> None:
        logger.info("Reader thread started")
        generator = None
        try:
            generator = self._reader_fn(self.path)
            for number, packet in generator:
                if self.stop_event.is_set():
                    break
                if not self.raw_queue.put((number, packet)):
                    break
                with self._lock:
                    self._counts["read"] += 1
        except Exception as exc:  # corrupt file etc.: report, then end the stream
            self._record_error("reader", exc, fatal=False)
        finally:
            if generator is not None and hasattr(generator, "close"):
                generator.close()
            self.raw_queue.close()
            self._thread_finished("reader")

    def _processor_loop(self) -> None:
        logger.info("Processor thread started")
        try:
            while True:
                item = self.raw_queue.get()
                if item is None or item is END:
                    break
                number, packet = item
                try:
                    record = self._parse_fn(packet, number)
                except Exception as exc:
                    with self._lock:
                        self._counts["malformed"] += 1
                    logger.debug("Skipping malformed packet %s: %s", number, exc)
                    continue
                if not self.parsed_queue.put(record):
                    break
                with self._lock:
                    self._counts["parsed"] += 1
        except Exception as exc:
            self._record_error("processor", exc, fatal=True)
        finally:
            self.parsed_queue.close()
            self._thread_finished("processor")

    def _stats_loop(self) -> None:
        logger.info("Statistics thread started")
        try:
            while True:
                record = self.parsed_queue.get()
                if record is None or record is END:
                    break
                self.stats.update(record)
                with self._records_lock:
                    if len(self._records) < self.max_records:
                        self._records.append(record)
                    else:
                        self._truncated = True
                with self._lock:
                    self._counts["stored"] += 1
        except Exception as exc:
            self._record_error("stats", exc, fatal=True)
        finally:
            self._thread_finished("stats")

    # ------------------------------------------------------------------- helpers
    def _record_error(self, source: str, exc: BaseException, fatal: bool) -> None:
        logger.error("%s thread error: %s", source, exc, exc_info=not isinstance(exc, ValueError))
        with self._lock:
            self._errors.append(f"{source}: {exc}")
        if fatal:
            self.stop_event.set()  # unblock the other threads

    def _thread_finished(self, name: str) -> None:
        with self._lock:
            self._alive -= 1
            last = self._alive == 0
            if last:
                if self._errors:
                    self._status = STATUS_FAILED
                elif self._stop_requested:
                    self._status = STATUS_STOPPED
                else:
                    self._status = STATUS_COMPLETED
                self._elapsed = time.perf_counter() - self._started_at
                status, counts, elapsed = self._status, dict(self._counts), self._elapsed
        logger.info("%s thread finished", name)
        if last:
            logger.info("Analysis %s in %.2fs: %s", status, elapsed, counts)
            self.finished_event.set()

    # ------------------------------------------------------------------- results
    def progress(self) -> Dict[str, Any]:
        with self._lock:
            info: Dict[str, Any] = dict(self._counts)
            info["status"] = self._status
            info["errors"] = list(self._errors)
        info["raw_queue_size"] = self.raw_queue.qsize()
        info["parsed_queue_size"] = self.parsed_queue.qsize()
        return info

    def result(self) -> Dict[str, Any]:
        """Statistics snapshot + record DataFrame (call after ``join``)."""
        with self._records_lock:
            records = list(self._records)
            truncated = self._truncated
        with self._lock:
            status = self._status
            errors = list(self._errors)
            counts = dict(self._counts)
            elapsed = self._elapsed
        return {
            "status": status,
            "errors": errors,
            "counts": counts,
            "elapsed_s": elapsed,
            "truncated": truncated,
            "max_records": self.max_records,
            "stats": self.stats.snapshot(),
            "dataframe": build_dataframe(records),
        }


def run_analysis(path: Union[str, Path], **kwargs: Any) -> Dict[str, Any]:
    """Blocking convenience wrapper: run the pipeline and return its result."""
    pipeline = AnalysisPipeline(path, **kwargs).start()
    pipeline.join()
    return pipeline.result()
