"""Stop-aware bounded queue used between pipeline threads.

Wraps ``queue.Queue`` (already thread-safe) and adds:
  * a bounded size -> back-pressure keeps memory usage constant,
  * short timeouts so blocked threads notice ``stop_event`` quickly,
  * an ``END`` sentinel that tells the consumer no more items will arrive.
"""
from __future__ import annotations

import queue
import threading
from typing import Any


class _EndOfStream:
    def __repr__(self) -> str:
        return "END"


END = _EndOfStream()


class PacketQueue:
    def __init__(
        self,
        maxsize: int,
        stop_event: threading.Event,
        poll_interval: float = 0.1,
        name: str = "queue",
    ) -> None:
        self._queue: "queue.Queue[Any]" = queue.Queue(maxsize=maxsize)
        self._stop = stop_event
        self._poll = poll_interval
        self.name = name

    def put(self, item: Any) -> bool:
        """Block until ``item`` is queued. Returns False if stop was requested."""
        while not self._stop.is_set():
            try:
                self._queue.put(item, timeout=self._poll)
                return True
            except queue.Full:
                continue
        return False

    def close(self) -> bool:
        """Signal end-of-stream to the consumer."""
        return self.put(END)

    def get(self) -> Any:
        """Return the next item, ``END``, or ``None`` if stopped while empty."""
        while True:
            try:
                return self._queue.get(timeout=self._poll)
            except queue.Empty:
                if self._stop.is_set():
                    return None

    def qsize(self) -> int:
        return self._queue.qsize()
