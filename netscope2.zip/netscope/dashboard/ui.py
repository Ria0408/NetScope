"""Shared dashboard helpers: theme CSS, session state and chart styling."""
from __future__ import annotations

import streamlit as st

from simulation.ns2_runner import load_saved_results

TCP_COLOR = "#4F8BF9"
UDP_COLOR = "#F2A33A"
PROTOCOL_COLORS = {"TCP": TCP_COLOR, "UDP": UDP_COLOR}

_CSS = """
<style>
div[data-testid="stMetric"] {
    background: #161B22; border: 1px solid #30363D; border-radius: 10px;
    padding: 14px 16px;
}
div[data-testid="stMetricLabel"] p { color: #8B949E; font-size: 0.85rem; }
h1, h2, h3 { letter-spacing: -0.01em; }
section[data-testid="stSidebar"] { border-right: 1px solid #30363D; }
footer { visibility: hidden; }
</style>
"""


def inject_css() -> None:
    st.markdown(_CSS, unsafe_allow_html=True)


def init_state() -> None:
    """Create session-state keys used across pages (idempotent)."""
    defaults = {
        "uploader_key": 0,
        "dataset_path": None,
        "upload_sig": None,
        "dataset_result": None,
    }
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)
    if "sim_results" not in st.session_state:
        st.session_state["sim_results"] = load_saved_results()
    st.session_state.setdefault("last_sim_key", None)


def _streamlit_version() -> tuple:
    parts = []
    for piece in st.__version__.split(".")[:2]:
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts)


# Streamlit >= 1.50 replaces use_container_width=True with width="stretch".
_NEW_WIDTH_API = _streamlit_version() >= (1, 50)


def plot(fig, container=None) -> None:
    """Render a Plotly figure full-width (works on old and new Streamlit)."""
    target = container if container is not None else st
    if _NEW_WIDTH_API:
        target.plotly_chart(fig, width="stretch")
    else:
        target.plotly_chart(fig, use_container_width=True)


def table(df, container=None, **kwargs) -> None:
    """Render a DataFrame full-width (works on old and new Streamlit)."""
    target = container if container is not None else st
    if _NEW_WIDTH_API:
        target.dataframe(df, width="stretch", **kwargs)
    else:
        target.dataframe(df, use_container_width=True, **kwargs)


def style_fig(fig, height: int = 360, keep_legend: bool = False):
    """Apply the dark Plotly look used everywhere."""
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        height=height,
        margin=dict(l=10, r=10, t=50, b=10),
    )
    if not keep_legend:
        fig.update_layout(
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
    return fig
