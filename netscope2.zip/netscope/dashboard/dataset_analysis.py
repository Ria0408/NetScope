"""Page 1 - dataset upload, multithreaded analysis, charts, packet table."""
from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from analysis.metrics import format_bps, format_bytes
from capture.dataset_reader import (
    InvalidCaptureError, get_dataset_info, list_datasets, save_uploaded_file,
)
from dashboard.ui import plot, style_fig, table
from processing.analytics import apply_filters
from processing.thread_manager import AnalysisPipeline

logger = logging.getLogger(__name__)
MAX_TABLE_ROWS = 5000


@st.cache_data(show_spinner=False)
def _dataset_info(path: str, mtime: float):
    return get_dataset_info(path)


def _reset() -> None:
    st.session_state["uploader_key"] += 1
    st.session_state["dataset_path"] = None
    st.session_state["upload_sig"] = None
    st.session_state["dataset_result"] = None


def _run_analysis(path: str, total_packets: int) -> None:
    """Start the 3-thread pipeline and poll it, so the UI keeps updating."""
    pipeline = AnalysisPipeline(path).start()
    bar = st.progress(0.0, text="Starting analysis threads...")
    while not pipeline.join(timeout=0.2):
        info = pipeline.progress()
        fraction = min(info["read"] / max(total_packets, 1), 1.0)
        bar.progress(
            fraction,
            text=(f"Reader: {info['read']:,} read | Processor: {info['parsed']:,} parsed | "
                  f"Stats: {info['stored']:,} aggregated"),
        )
    bar.progress(1.0, text="Analysis finished")
    result = pipeline.result()
    st.session_state["dataset_result"] = {"path": path, "result": result}
    logger.info("Dataset analysis stored for %s", Path(path).name)


def _charts(stats: dict) -> None:
    left, right = st.columns(2)
    proto = pd.DataFrame(
        {"protocol": list(stats["protocol_counts"]), "packets": list(stats["protocol_counts"].values())}
    )
    proto = proto.sort_values("packets", ascending=False)
    share = proto["packets"] / proto["packets"].sum() * 100
    proto["label"] = [f"{name} ({pct:.2f}%)" for name, pct in zip(proto["protocol"], share)]
    fig = px.pie(proto, names="label", values="packets", hole=0.5,
                 title="Protocol distribution")
    # Percent text only inside big slices; every protocol's share is in the legend,
    # so small slices never overlap each other.
    fig.update_traces(textposition="inside", textinfo="percent", sort=False,
                      insidetextorientation="horizontal",
                      marker=dict(line=dict(color="#0E1117", width=2)))
    fig.update_layout(
        uniformtext_minsize=11, uniformtext_mode="hide",
        legend=dict(orientation="v", yanchor="middle", y=0.5, xanchor="left", x=1.02),
        margin=dict(l=10, r=10, t=50, b=10),
    )
    plot(style_fig(fig, 380, keep_legend=True), left)

    hist = pd.DataFrame(stats["size_histogram"])
    fig = px.bar(hist, x="range", y="packets", title="Packet size distribution (bytes)")
    fig.update_xaxes(title="Packet size range (bytes)")
    plot(style_fig(fig), right)

    left, right = st.columns(2)
    for column, key, title in ((left, "top_sources", "Top source IPs"),
                               (right, "top_destinations", "Top destination IPs")):
        data = pd.DataFrame(stats[key], columns=["ip", "packets"])
        if data.empty:
            column.info("No IP-layer packets found.")
            continue
        fig = px.bar(data.iloc[::-1], x="packets", y="ip", orientation="h", title=title)
        plot(style_fig(fig), column)

    timeline = pd.DataFrame(stats["timeline"])
    if len(timeline) > 1:
        fig = px.area(timeline, x="second", y="packets", title="Packets per second over time")
        fig.update_xaxes(title="Seconds since first packet")
        plot(style_fig(fig, 300))


def _table(df: pd.DataFrame) -> None:
    st.subheader("Packet details")
    protocols = sorted(df["protocol"].unique())
    c1, c2, c3, c4 = st.columns(4)
    chosen = c1.multiselect("Protocol", protocols)
    src = c2.text_input("Source IP contains")
    dst = c3.text_input("Destination IP contains")
    port_text = c4.text_input("Port (src or dst)")
    port = None
    if port_text.strip():
        if port_text.strip().isdigit() and 0 <= int(port_text) <= 65535:
            port = int(port_text)
        else:
            st.warning("Port must be a number between 0 and 65535.")
    filtered = apply_filters(df, chosen, src, dst, port)
    st.caption(f"{len(filtered):,} of {len(df):,} packets match"
               + (f" - showing first {MAX_TABLE_ROWS:,}" if len(filtered) > MAX_TABLE_ROWS else ""))
    view = filtered.head(MAX_TABLE_ROWS).copy()
    view["time"] = pd.to_datetime(view["timestamp"], unit="s").dt.strftime("%H:%M:%S.%f")
    cols = ["number", "time", "src_ip", "dst_ip", "src_port", "dst_port",
            "protocol", "length", "tcp_flags"]
    table(view[cols], hide_index=True, height=420)


def render() -> None:
    st.header("Dataset Analysis")
    st.caption("Upload a captured .pcap / .pcapng file (for example saved from Wireshark).")

    up_col, reset_col = st.columns([5, 1])
    uploaded = up_col.file_uploader(
        "PCAP / PCAPNG file", type=["pcap", "pcapng"],
        key=f"uploader_{st.session_state['uploader_key']}",
    )
    reset_col.write("")
    reset_col.write("")
    reset_col.button("Reset / new file", on_click=_reset)

    if uploaded is not None:
        signature = (uploaded.name, uploaded.size)
        if st.session_state["upload_sig"] != signature:
            try:
                saved = save_uploaded_file(uploaded.name, uploaded.getbuffer())
            except InvalidCaptureError as exc:
                st.error(f"Invalid file: {exc}")
                return
            except OSError as exc:
                st.error(f"Could not save the file: {exc}")
                return
            st.session_state.update(
                dataset_path=str(saved), upload_sig=signature, dataset_result=None)

    saved_files = list_datasets()
    if saved_files:
        names = [p.name for p in saved_files]
        current = Path(st.session_state["dataset_path"]).name if st.session_state["dataset_path"] else None
        index = names.index(current) if current in names else None
        choice = st.selectbox("Select dataset to analyze", names, index=index,
                              placeholder="Choose an uploaded dataset")
        if choice and choice != current:
            st.session_state.update(
                dataset_path=str(saved_files[names.index(choice)].parent / choice),
                dataset_result=None)
            st.rerun()

    path = st.session_state["dataset_path"]
    if not path:
        st.info("Upload a capture file to begin.")
        return

    try:
        with st.spinner("Reading capture..."):
            info = _dataset_info(path, Path(path).stat().st_mtime)
    except (InvalidCaptureError, OSError) as exc:
        st.error(f"Could not read dataset: {exc}")
        return

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Filename", info["filename"])
    c2.metric("File size", info["size_human"])
    c3.metric("Format", str(info["format"]).upper())
    c4.metric("Packets in file", f"{info['packets']:,}")

    if st.button("Analyze dataset", type="primary"):
        _run_analysis(path, int(info["packets"]))

    stored = st.session_state["dataset_result"]
    if not stored or stored["path"] != path:
        return
    result = stored["result"]
    stats = result["stats"]

    for error in result["errors"]:
        st.error(f"Analysis error - {error}")
    if stats["total_packets"] == 0:
        st.warning("No packets could be analyzed.")
        return
    if result["status"] == "failed":
        st.warning("Showing partial results from packets processed before the error.")
    if result["truncated"]:
        st.warning(f"Statistics cover all {stats['total_packets']:,} packets; the table keeps "
                   f"the first {result['max_records']:,} to limit memory.")
    if result["counts"]["malformed"]:
        st.caption(f"{result['counts']['malformed']:,} malformed packets were skipped.")

    st.subheader("Summary")
    m1, m2, m3 = st.columns(3)
    m1.metric("Total packets", f"{stats['total_packets']:,}")
    m2.metric("Total data transferred", format_bytes(stats["total_bytes"]))
    m3.metric("Capture duration", f"{stats['duration_s']:.2f} s")
    m4, m5, m6 = st.columns(3)
    m4.metric("Observed throughput", format_bps(stats["throughput_bps"]))
    m5.metric("Packets per second", f"{stats['packets_per_second']:.2f}")
    m6.metric("Unique hosts (src / dst)",
              f"{stats['unique_sources']} / {stats['unique_destinations']}")
    st.caption(f"Processed by 3 threads in {result['elapsed_s']:.2f} s. Values are observed from the "
               "capture; a PCAP alone has no sender/receiver pairing, so end-to-end loss and delay "
               "come from the NS-2 simulation instead.")

    _charts(stats)
    _table(result["dataframe"])
