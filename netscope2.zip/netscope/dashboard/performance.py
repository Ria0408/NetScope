"""Page 3 - performance analytics: dataset summary and TCP vs UDP comparison."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from analysis import trace_parser
from analysis.metrics import format_bps, format_bytes
from dashboard.ui import TCP_COLOR, UDP_COLOR, plot, style_fig, table
from simulation.topology_generator import TOPOLOGIES

COLORS = {"TCP": TCP_COLOR, "UDP": UDP_COLOR}


def _dataset_section() -> None:
    st.subheader("Dataset performance summary")
    stored = st.session_state.get("dataset_result")
    if not stored:
        st.info("No dataset analyzed yet. Analyze a capture on the Dataset Analysis page.")
        return
    stats = stored["result"]["stats"]
    if stats["total_packets"] == 0:
        st.info("The analyzed dataset contained no packets.")
        return
    st.caption(f"Dataset: {Path(stored['path']).name}")
    m = st.columns(4)
    m[0].metric("Total packets", f"{stats['total_packets']:,}")
    m[1].metric("Total data", format_bytes(stats["total_bytes"]))
    m[2].metric("Throughput", format_bps(stats["throughput_bps"]))
    m[3].metric("Packets / second", f"{stats['packets_per_second']:.2f}")

    timeline = pd.DataFrame(stats["timeline"])
    left, right = st.columns(2)
    if len(timeline) > 1:
        timeline["throughput_kbps"] = timeline["bytes"] * 8 / 1000.0
        fig = px.line(timeline, x="second", y="throughput_kbps",
                      title="Observed throughput over time (1 s bins)")
        fig.update_xaxes(title="Seconds since first packet")
        fig.update_yaxes(title="kbps")
        plot(style_fig(fig, 320), left)
    volume = pd.DataFrame({"protocol": list(stats["protocol_bytes"]),
                           "bytes": list(stats["protocol_bytes"].values())})
    fig = px.bar(volume.sort_values("bytes", ascending=False), x="protocol", y="bytes",
                 title="Data volume by protocol")
    plot(style_fig(fig, 320), right)
    st.caption("A PCAP contains only what one capture point observed, so packet loss, delivery "
               "ratio and end-to-end delay are not computed for datasets. See the NS-2 section below.")


def _comparison_frame(runs: dict) -> pd.DataFrame:
    rows = []
    for traffic, result in runs.items():
        o = result["overall"]
        rows.append({
            "Protocol": traffic.upper(),
            "Packets sent": o["packets_sent"],
            "Packets received": o["packets_received"],
            "Packets dropped": o["packets_dropped"],
            "Throughput (kbps)": o["throughput_bps"] / 1000.0,
            "Packet loss (%)": o["loss_percent"],
            "PDR (%)": o["pdr_percent"],
            "Avg delay (ms)": o["avg_delay_ms"],
            "Packets / s": o["packets_per_second"],
        })
    return pd.DataFrame(rows)


def _bar(df: pd.DataFrame, column: str, title: str, container) -> None:
    fig = px.bar(df, x="Protocol", y=column, color="Protocol", color_discrete_map=COLORS,
                 title=title, text_auto=".2f")
    fig.update_layout(showlegend=False)
    plot(style_fig(fig, 320), container)


def _simulation_section() -> None:
    st.subheader("NS-2 simulation performance")
    results = st.session_state.get("sim_results", {})
    available = [t for t in TOPOLOGIES if any(k.startswith(f"{t}|") for k in results)]
    if not available:
        st.info("No simulation results yet. Run a simulation on the NS-2 Simulation page "
                "(use 'Run TCP and UDP' for a comparison).")
        return
    topology = st.radio("Topology", available, horizontal=True,
                        format_func=lambda k: TOPOLOGIES[k]["label"], key="perf_topology")
    runs = {t: results[f"{topology}|{t}"] for t in ("tcp", "udp") if f"{topology}|{t}" in results}
    if len(runs) < 2:
        missing = "UDP" if "tcp" in runs else "TCP"
        st.warning(f"Only one transport has been simulated on this topology. Run {missing} "
                   "as well to see the comparison.")

    frame = _comparison_frame(runs)
    table(frame.round(3), hide_index=True)
    for traffic, result in runs.items():
        cfg = result["config"]
        st.caption(f"{traffic.upper()}: bandwidth {cfg['bandwidth']}, delay {cfg['delay']}, "
                   f"queue {cfg['queue_limit']}, duration {cfg['duration']:g}s, "
                   f"CBR rate {cfg['cbr_rate']} (UDP only), run at {result['created']}")
    if len(runs) == 2 and runs["tcp"]["config"] != {**runs["udp"]["config"], "traffic": "tcp"}:
        st.warning("TCP and UDP were run with different settings, so the comparison is not "
                   "like-for-like.")

    c1, c2 = st.columns(2)
    _bar(frame, "Throughput (kbps)", "Throughput", c1)
    counts = frame.melt(id_vars="Protocol", value_vars=["Packets sent", "Packets received", "Packets dropped"],
                        var_name="Metric", value_name="Packets")
    fig = px.bar(counts, x="Metric", y="Packets", color="Protocol", barmode="group",
                 color_discrete_map=COLORS, title="Packet counts")
    plot(style_fig(fig, 320), c2)

    c3, c4, c5 = st.columns(3)
    _bar(frame, "Packet loss (%)", "Packet loss", c3)
    _bar(frame, "PDR (%)", "Packet delivery ratio", c4)
    _bar(frame, "Avg delay (ms)", "Average end-to-end delay", c5)

    series = []
    for traffic, result in runs.items():
        trace = Path(result["trace_path"])
        if trace.is_file():
            ts = trace_parser.load_timeseries(trace, bin_s=0.5, aggregate=True)
            ts["Protocol"] = traffic.upper()
            series.append(ts)
    if series:
        fig = px.line(pd.concat(series), x="time", y="throughput_kbps", color="Protocol",
                      color_discrete_map=COLORS, title="Aggregate received throughput over time")
        fig.update_xaxes(title="Simulation time (s)")
        fig.update_yaxes(title="kbps")
        plot(style_fig(fig))


def render() -> None:
    st.header("Performance Analytics")
    _dataset_section()
    st.divider()
    _simulation_section()
