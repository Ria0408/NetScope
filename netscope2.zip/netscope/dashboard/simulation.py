"""Page 2 - configure and run NS-2 simulations, show trace analysis."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from analysis import trace_parser
from analysis.metrics import format_bps
from dashboard.ui import plot, style_fig, table
from simulation.ns2_runner import (
    NS2NotFoundError, SimulationError, find_ns2_binary, run_and_analyze,
)
from simulation.topology_generator import (
    TOPOLOGIES, TRAFFIC_LABELS, SimulationConfig, get_layout,
)


@st.cache_data(show_spinner=False)
def _timeseries(trace_path: str, mtime: float) -> pd.DataFrame:
    return trace_parser.load_timeseries(trace_path, bin_s=0.5)


def topology_figure(topology: str) -> go.Figure:
    nodes, edges, bottlenecks, flows = get_layout(topology)
    fig = go.Figure()
    for a, b in edges:
        is_bottleneck = (a, b) in bottlenecks
        fig.add_trace(go.Scatter(
            x=[nodes[a][0], nodes[b][0]], y=[nodes[a][1], nodes[b][1]], mode="lines",
            line=dict(width=7 if is_bottleneck else 3,
                      color="#F85149" if is_bottleneck else "#6E7681"),
            hoverinfo="skip", showlegend=False))
    palette = ["#4F8BF9", "#F2A33A"]
    for i, (src, dst) in enumerate(flows):
        fig.add_annotation(
            x=nodes[dst][0], y=nodes[dst][1], ax=nodes[src][0], ay=nodes[src][1],
            xref="x", yref="y", axref="x", ayref="y", showarrow=True, arrowhead=3,
            arrowwidth=2, arrowcolor=palette[i % 2], opacity=0.9)
    fig.add_trace(go.Scatter(
        x=[n[0] for n in nodes.values()], y=[n[1] for n in nodes.values()],
        mode="markers+text", text=[n[2] for n in nodes.values()], textposition="top center",
        marker=dict(size=26, color="#238636", line=dict(width=2, color="#E6EDF3")),
        hoverinfo="text", showlegend=False))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    title = f"{TOPOLOGIES[topology]['label']} topology"
    if bottlenecks:
        title += " (red = bottleneck link, arrows = flows)"
    else:
        title += " (arrows = flows)"
    fig.update_layout(title=title)
    return style_fig(fig, 340)


def _run(configs: list) -> None:
    with st.status("Running NS-2 simulation...", expanded=True) as status:
        for cfg in configs:
            st.write(f"Running {cfg.traffic.upper()} on the {TOPOLOGIES[cfg.topology]['label']} topology...")
            try:
                result = run_and_analyze(cfg)
            except NS2NotFoundError as exc:
                status.update(label="NS-2 not found", state="error")
                st.error(str(exc))
                return
            except (SimulationError, trace_parser.TraceParseError, ValueError) as exc:
                status.update(label="Simulation failed", state="error")
                st.error(str(exc))
                return
            st.session_state["sim_results"][result["key"]] = result
            st.session_state["last_sim_key"] = result["key"]
            st.write(f"Done in {result['runtime_s']:.2f} s - trace: {Path(result['trace_path']).name}")
        status.update(label="Simulation complete", state="complete", expanded=False)


def _show_result(result: dict) -> None:
    overall = result["overall"]
    label = TOPOLOGIES[result["topology"]]["label"]
    st.subheader(f"Results - {label}, {result['traffic'].upper()}")

    m = st.columns(4)
    m[0].metric("Packets sent", f"{overall['packets_sent']:,}")
    m[1].metric("Packets received", f"{overall['packets_received']:,}")
    m[2].metric("Packets dropped", f"{overall['packets_dropped']:,}")
    m[3].metric("Throughput", format_bps(overall["throughput_bps"]))
    m = st.columns(4)
    m[0].metric("Packet delivery ratio", f"{overall['pdr_percent']:.2f} %")
    m[1].metric("Packet loss", f"{overall['loss_percent']:.2f} %")
    m[2].metric("Average delay", f"{overall['avg_delay_ms']:.2f} ms")
    m[3].metric("Packets per second", f"{overall['packets_per_second']:.1f}")

    flows = pd.DataFrame(result["flows"])
    flows["path"] = flows["src_node"].astype(str).radd("n") + " -> n" + flows["dst_node"].astype(str)
    flow_table = flows[["flow_id", "path", "pkt_type", "packets_sent", "packets_received",
                   "packets_dropped", "pdr_percent", "loss_percent", "avg_delay_ms"]].copy()
    flow_table["throughput_kbps"] = flows["throughput_bps"] / 1000.0
    table(flow_table.round(3), hide_index=True)

    trace = Path(result["trace_path"])
    if trace.is_file():
        series = _timeseries(str(trace), trace.stat().st_mtime)
        fig = px.line(series, x="time", y="throughput_kbps", color="flow",
                      title="Received throughput over time (0.5 s bins)")
        fig.update_xaxes(title="Simulation time (s)")
        fig.update_yaxes(title="Throughput (kbps)")
        plot(style_fig(fig))

    if result.get("awk_consistent") is True:
        st.success("AWK cross-check agrees with the Python/Pandas analysis "
                   f"(sent={int(result['awk']['sent'])}, received={int(result['awk']['received'])}, "
                   f"dropped={int(result['awk']['dropped'])}).")
    elif result.get("awk_consistent") is False:
        st.warning("AWK summary differs from the Pandas analysis - inspect the trace file.")

    st.caption(
        "Packet loss = sent - received at the destination (drops at the queue plus packets "
        "still in flight when the simulation ended). TCP retransmissions count as new packets.")
    with st.expander("Output files"):
        st.write(f"Trace file: `{result['trace_path']}`")
        if result.get("nam_path"):
            st.write(f"NAM file: `{result['nam_path']}` (open with `nam <file>`)")
        if trace.is_file():
            st.download_button("Download trace (.tr)", trace.read_bytes(),
                               file_name=trace.name, key=f"dl_{trace.name}")


def render() -> None:
    st.header("NS-2 Simulation")
    binary = find_ns2_binary()
    if binary:
        st.success(f"NS-2 found: {binary}")
    else:
        st.error("NS-2 was not found. Install it (Ubuntu/WSL: `sudo apt install ns2 nam`) "
                 "or set the NS2_PATH environment variable, then restart the dashboard.")

    topology = st.radio("Topology", list(TOPOLOGIES), horizontal=True,
                        format_func=lambda k: TOPOLOGIES[k]["label"])
    traffic = st.radio("Transport / traffic", list(TRAFFIC_LABELS), horizontal=True,
                       format_func=lambda k: TRAFFIC_LABELS[k])
    defaults = TOPOLOGIES[topology]["defaults"]
    bottleneck = topology == "bottleneck"

    c1, c2, c3 = st.columns(3)
    bw = c1.number_input("Bottleneck bandwidth (Mbps)" if bottleneck else "Link bandwidth (Mbps)",
                         0.1, 1000.0, float(defaults["bw"]), 0.1, key=f"{topology}_bw")
    delay = c2.number_input("Bottleneck delay (ms)" if bottleneck else "Link delay (ms)",
                            0.1, 1000.0, float(defaults["delay"]), 1.0, key=f"{topology}_delay")
    queue = c3.number_input("Queue limit (packets)", 1, 10000, int(defaults["queue"]),
                            key=f"{topology}_queue")
    c4, c5, c6 = st.columns(3)
    duration = c4.number_input("Duration (s)", 2.0, 600.0, 10.0, 1.0, key=f"{topology}_dur")
    pkt_size = c5.number_input("Packet size (bytes)", 40, 1500, 1000, key=f"{topology}_pkt")
    if traffic == "udp":
        rate = c6.number_input("CBR rate per flow (Mbps)", 0.01, 1000.0,
                               float(defaults["rate"]), 0.1, key=f"{topology}_rate")
    else:
        c6.caption("FTP over TCP sends as fast as TCP congestion control allows.")
        rate = float(defaults["rate"])
    abw, adelay = 10.0, 1.0
    if bottleneck:
        c7, c8, _ = st.columns(3)
        abw = c7.number_input("Access link bandwidth (Mbps)", 0.1, 1000.0, 10.0, 1.0, key="b_abw")
        adelay = c8.number_input("Access link delay (ms)", 0.1, 1000.0, 1.0, 1.0, key="b_adelay")

    def make_cfg(kind: str) -> SimulationConfig:
        return SimulationConfig(
            topology=topology, traffic=kind, bandwidth=f"{bw:g}Mb", delay=f"{delay:g}ms",
            queue_limit=int(queue), duration=float(duration), cbr_rate=f"{rate:g}Mb",
            packet_size=int(pkt_size), access_bandwidth=f"{abw:g}Mb", access_delay=f"{adelay:g}ms")

    b1, b2, _ = st.columns([1, 1.4, 3])
    run_one = b1.button("Run simulation", type="primary", disabled=binary is None)
    run_both = b2.button("Run TCP and UDP (compare)", disabled=binary is None)
    if run_one:
        _run([make_cfg(traffic)])
    elif run_both:
        _run([make_cfg("tcp"), make_cfg("udp")])

    plot(topology_figure(topology))

    results = st.session_state["sim_results"]
    last = st.session_state.get("last_sim_key")
    if last in results:
        _show_result(results[last])
    elif results:
        st.info("Showing the most recent saved simulation.")
        _show_result(sorted(results.values(), key=lambda r: r["created"])[-1])
    else:
        st.info("Run a simulation to see trace analysis here.")
