"""NetScope - Network Traffic Analyzer (Streamlit entry point).

Run:  streamlit run app.py
"""
import streamlit as st

import config

config.setup_logging()

st.set_page_config(page_title="NetScope", page_icon="📡", layout="wide")

from dashboard import dataset_analysis, performance, simulation, ui  # noqa: E402

ui.inject_css()
ui.init_state()

PAGES = {
    "Dataset Analysis": dataset_analysis.render,
    "NS-2 Simulation": simulation.render,
    "Performance Analytics": performance.render,
}

with st.sidebar:
    st.title("📡 NetScope")
    st.caption("Network Traffic Analyzer")
    page = st.radio("Navigate", list(PAGES), label_visibility="collapsed")
    st.divider()
    st.caption("Scapy · NS-2 · threading · Pandas · Plotly")

PAGES[page]()
