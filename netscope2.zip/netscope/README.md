# NetScope – Network Traffic Analyzer

Computer Networks Lab project. Analyzes captured packet files (PCAP/PCAPNG) with a
3-thread pipeline, simulates TCP vs UDP in NS-2, and shows everything in a dark Streamlit
dashboard. No live capture; no hard-coded results — every number is computed from your
file or from the NS-2 trace.

## Six features

| # | Feature | Where |
|---|---------|-------|
| 1 | PCAP/PCAPNG upload, validation, reset | `capture/dataset_reader.py`, Page 1 |
| 2 | Packet + protocol analysis, filters | `capture/packet_parser.py`, `processing/analytics.py` |
| 3 | Multithreaded processing | `processing/thread_manager.py`, `packet_queue.py` |
| 4 | NS-2 simulation (star, bottleneck; TCP/FTP, UDP/CBR) | `simulation/` |
| 5 | Performance analytics | `analysis/metrics.py`, `analysis/trace_parser.py` |
| 6 | Dashboard (3 pages) | `app.py`, `dashboard/` |

## Setup (Ubuntu / WSL recommended)

```bash
sudo apt update
sudo apt install -y ns2 nam python3-venv     # NS-2 + NAM viewer
cd netscope
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
ns -h 2>&1 | head -1     # NS-2 sanity check (prints usage / exits)
```

Windows: run everything inside WSL (Ubuntu) so the dashboard can call `ns`. Without NS-2
pages 1 and 3 (dataset part) still work; page 2 shows how to install it. If `ns` is not on
PATH, set `NS2_PATH=/full/path/to/ns`.

## Run

```bash
streamlit run app.py                      # opens http://localhost:8501
python tools/make_sample_pcap.py data/sample.pcap 2000   # optional demo capture
pytest -q                                  # unit tests
```

## Using the dashboard

1. **Dataset Analysis** – upload a `.pcap/.pcapng` (e.g. saved from Wireshark) → *Analyze dataset*.
   Use the protocol / IP / port filters on the packet table. *Reset / new file* clears it.
2. **NS-2 Simulation** – pick topology, TCP or UDP, bandwidth, delay, queue, duration,
   packet size (and CBR rate for UDP) → *Run simulation*, or *Run TCP and UDP (compare)*.
   Traces go to `data/traces/` (`.tr` and `.nam`), summaries to `data/results/`.
   View animation: `nam data/traces/<file>.nam`.
3. **Performance Analytics** – dataset summary plus TCP vs UDP charts (throughput, packet
   counts, loss, delay, PDR) from your simulation runs.

Verify with Wireshark: open the same capture, compare *Statistics → Capture File Properties*
(packets, bytes, duration) and *Statistics → Protocol Hierarchy* with NetScope's page 1.

## Architecture

```
upload ─► capture/dataset_reader ─► processing/thread_manager (3 threads) ─► analytics ─► dashboard
NS-2 UI ─► simulation/topology_generator ─► ns2_runner (subprocess: ns *.tcl) ─► data/traces/*.tr
                                              └► analysis/trace_parser (Pandas + AWK) ─► metrics ─► dashboard
```

## Multithreading design

```
Reader thread ──raw_queue──► Processor thread ──parsed_queue──► Statistics thread
(PcapReader)    (bounded)    (parse + classify)  (bounded)       (TrafficStats + records)
```

| Thread | Responsibility |
|--------|----------------|
| `netscope-reader` | Streams packets from the file, pushes `(number, packet)` |
| `netscope-processor` | Extracts IPs, ports, protocol, size, TCP flags; classifies |
| `netscope-stats` | Updates packet counts, bytes, protocol distribution, top talkers, size histogram, timeline |

**Synchronization**
- `queue.Queue` (inside `PacketQueue`) is internally locked and **bounded** → back-pressure keeps memory flat.
- `threading.Lock`: `TrafficStats` guards every update *and* snapshot, so the UI reads while the stats thread writes; `AnalysisPipeline` has separate locks for counters/errors and for the stored records.
- `threading.Event`: `stop_event` (cooperative cancel – all blocking queue calls poll it), `finished_event` (set by the last thread to exit).
- Graceful termination: reader sends an `END` sentinel; each stage forwards it, so every queued packet is processed. A fatal error in a stage sets `stop_event`, so the others never deadlock.
- The dashboard only polls `progress()` every 0.2 s while the threads work, so it stays responsive.

Note: CPython's GIL means CPU-bound parsing is not truly parallel; the pipeline still overlaps
file I/O, parsing and aggregation and demonstrates the producer–consumer pattern.

## NS-2 topologies

- **Star** (`star_topology.tcl`): hub n0 + leaves n1–n4, duplex links; flows n1→n3 and n2→n4.
- **Bottleneck** (`bottleneck.tcl`): n0,n1 → router n2 ⇄ **bottleneck** ⇄ router n3 → n4,n5; flows n0→n4, n1→n5.
  Default 1 Mb / 20 ms / queue 10 bottleneck against fast 10 Mb access links; with UDP the offered
  load (2 × 1 Mb) exceeds capacity, so the queue overflows and packets drop.
- TCP = `Agent/TCP` + `Application/FTP`; UDP = `Agent/UDP` + `Application/Traffic/CBR`.

Run a script by hand:
```bash
ns simulation/bottleneck.tcl traffic udp bw 1Mb delay 20ms queue 10 duration 10 trace /tmp/b.tr nam none
awk -f analysis/trace_summary.awk /tmp/b.tr
```

## Metrics

```
Throughput  = (Total Bytes × 8) / Time Interval
PDR         = (Received / Sent) × 100
Packet loss = ((Sent − Received) / Sent) × 100
Avg delay   = Total packet delay / Received packets
```
- **NS-2 traces**: data packets only (`tcp`, `cbr`). *Sent* = first-hop enqueue at the source node,
  *received* = last-hop receive at the destination node, delay = receive − send time of the same
  packet id. Time interval = first send → last receive. Loss includes packets still in flight when the
  simulation stops; TCP retransmissions count as new packets. `analysis/trace_summary.awk`
  independently recomputes sent/received/dropped/delay and the dashboard shows whether it agrees.
- **PCAP datasets**: only observed packets, bytes, throughput and packets/s. A single capture has no
  sender/receiver pairing, so loss and end-to-end delay are *not* claimed for datasets.

## Folder structure

```
netscope/
├── app.py  config.py  requirements.txt  README.md
├── capture/      dataset_reader.py  packet_parser.py
├── processing/   thread_manager.py  packet_queue.py  analytics.py
├── simulation/   ns2_runner.py  topology_generator.py  star_topology.tcl  bottleneck.tcl
├── analysis/     trace_parser.py  metrics.py  trace_summary.awk
├── dashboard/    dataset_analysis.py  simulation.py  performance.py  ui.py
├── tools/        make_sample_pcap.py
├── data/         uploaded_datasets/  traces/  results/
└── tests/        test_parser.py  test_metrics.py  test_threading.py  test_simulation.py
```

## Troubleshooting

- *"NS-2 was not found"* → `sudo apt install ns2`, or set `NS2_PATH`.
- *Upload rejected* → file must be a real `.pcap`/`.pcapng` (checked by file signature, not just extension).
- Very large captures: statistics cover every packet, the table keeps the first 200,000 (`max_records`).
- Logs: `data/netscope.log`.

## Screenshots

Run the dashboard, then save screenshots of each page into `docs/screenshots/` and link them here.
