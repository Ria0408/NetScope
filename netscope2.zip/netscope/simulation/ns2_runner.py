"""Run NS-2 through ``subprocess``, analyze the trace, and persist results."""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import time
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import config
from analysis import trace_parser
from simulation.topology_generator import SimulationConfig, build_tcl_args, get_script_path

logger = logging.getLogger(__name__)


class NS2NotFoundError(RuntimeError):
    """NS-2 executable could not be located."""


class SimulationError(RuntimeError):
    """NS-2 ran but failed or produced no usable trace."""


def find_ns2_binary() -> Optional[str]:
    """Locate the NS-2 executable (env var ``NS2_PATH``, then ``ns`` / ``ns2``)."""
    env_path = os.environ.get("NS2_PATH")
    if env_path:
        resolved = shutil.which(env_path)
        if resolved:
            return resolved
    for name in ("ns", "ns2"):
        resolved = shutil.which(name)
        if resolved:
            return resolved
    return None


def run_simulation(cfg: SimulationConfig, timeout: int = 180) -> Dict[str, Any]:
    """Execute the Tcl script for ``cfg``; return paths and run information."""
    cfg.validate()
    binary = find_ns2_binary()
    if binary is None:
        raise NS2NotFoundError(
            "NS-2 was not found on PATH. Install it (Ubuntu/WSL: "
            "`sudo apt install ns2 nam`) or set the NS2_PATH environment variable."
        )

    config.ensure_dirs()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    base = f"{cfg.topology}_{cfg.traffic}_{stamp}"
    trace_path = config.TRACE_DIR / f"{base}.tr"
    nam_path = config.TRACE_DIR / f"{base}.nam"
    script = get_script_path(cfg.topology)
    command = [binary, str(script), *build_tcl_args(cfg, trace_path, nam_path)]
    logger.info("Running NS-2: %s", " ".join(command))

    started = time.perf_counter()
    try:
        proc = subprocess.run(
            command, capture_output=True, text=True, timeout=timeout, cwd=config.TRACE_DIR,
        )
    except subprocess.TimeoutExpired as exc:
        raise SimulationError(f"NS-2 timed out after {timeout}s") from exc
    except OSError as exc:
        raise SimulationError(f"Could not start NS-2: {exc}") from exc
    runtime = time.perf_counter() - started

    if proc.returncode != 0:
        tail = (proc.stderr or proc.stdout or "").strip()[-600:]
        raise SimulationError(f"NS-2 exited with code {proc.returncode}: {tail}")
    if not trace_path.is_file() or trace_path.stat().st_size == 0:
        raise SimulationError("NS-2 finished but produced no trace file.")

    return {
        "trace_path": str(trace_path),
        "nam_path": str(nam_path) if cfg.generate_nam and nam_path.is_file() else None,
        "runtime_s": runtime,
        "stderr": (proc.stderr or "").strip(),
    }


def run_and_analyze(cfg: SimulationConfig, timeout: int = 180) -> Dict[str, Any]:
    """Run a simulation, analyze its trace, save a JSON summary, return it."""
    run = run_simulation(cfg, timeout=timeout)
    analysis = trace_parser.analyze_trace(run["trace_path"])
    awk = trace_parser.awk_summary(run["trace_path"])
    result = {
        "key": f"{cfg.topology}|{cfg.traffic}",
        "topology": cfg.topology,
        "traffic": cfg.traffic,
        "config": asdict(cfg),
        "created": datetime.now().isoformat(timespec="seconds"),
        "awk": awk,
        "awk_consistent": trace_parser.awk_matches(analysis["overall"], awk),
        **run,
        **analysis,
    }
    save_result(result)
    return result


def save_result(result: Dict[str, Any]) -> Path:
    """Write the result summary to ``data/results``."""
    config.ensure_dirs()
    name = Path(result["trace_path"]).stem + ".json"
    target = config.RESULTS_DIR / name
    target.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return target


def load_saved_results() -> Dict[str, Dict[str, Any]]:
    """Latest saved result per ``topology|traffic`` key (skips missing traces)."""
    latest: Dict[str, Dict[str, Any]] = {}
    if not config.RESULTS_DIR.is_dir():
        return latest
    for file in sorted(config.RESULTS_DIR.glob("*.json")):
        try:
            data = json.loads(file.read_text(encoding="utf-8"))
            if "key" not in data or not Path(data["trace_path"]).is_file():
                continue
        except (OSError, ValueError, KeyError):
            continue
        current = latest.get(data["key"])
        if current is None or data["created"] >= current["created"]:
            latest[data["key"]] = data
    return latest
