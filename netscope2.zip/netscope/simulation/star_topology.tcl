# =============================================================================
# NetScope - Topology 1: five-node star (NS-2)
#
#            n3                n4
#              \              /
#               \            /
#                +---- n0 ---+        n0 = hub, n1..n4 = leaf nodes
#               /            \
#              /              \
#            n1                n2
#
# Flow 1: n1 -> n3     Flow 2: n2 -> n4   (both cross the hub)
#
# Run:  ns star_topology.tcl traffic tcp bw 2Mb delay 10ms queue 20 \
#          duration 10 rate 1Mb pktsize 1000 trace star.tr nam star.nam
#
#   traffic  tcp -> Agent/TCP + Application/FTP
#            udp -> Agent/UDP + Application/Traffic/CBR
#   nam      file name, or "none" to skip the NAM trace
# =============================================================================

# ---- defaults (override with key/value pairs on the command line) -----------
set opt(traffic)  tcp
set opt(bw)       2Mb
set opt(delay)    10ms
set opt(queue)    20
set opt(duration) 10.0
set opt(rate)     1Mb
set opt(pktsize)  1000
set opt(trace)    star.tr
set opt(nam)      star.nam

foreach {key value} $argv {
    set opt([string trimleft $key -]) $value
}

if {$opt(traffic) != "tcp" && $opt(traffic) != "udp"} {
    puts stderr "ERROR: traffic must be tcp or udp (got $opt(traffic))"
    exit 1
}

# ---- simulator and trace files ----------------------------------------------
set ns [new Simulator]

set tf [open $opt(trace) w]
$ns trace-all $tf

if {$opt(nam) != "none"} {
    set nf [open $opt(nam) w]
    $ns namtrace-all $nf
}

proc finish {} {
    global ns tf nf opt
    $ns flush-trace
    close $tf
    if {$opt(nam) != "none"} {
        close $nf
    }
    exit 0
}

# ---- nodes: hub is node 0, leaves are nodes 1-4 -----------------------------
set hub [$ns node]
for {set i 1} {$i <= 4} {incr i} {
    set leaf($i) [$ns node]
}

# ---- duplex links (hub <-> each leaf) ---------------------------------------
for {set i 1} {$i <= 4} {incr i} {
    $ns duplex-link $hub $leaf($i) $opt(bw) $opt(delay) DropTail
    $ns queue-limit $hub $leaf($i) $opt(queue)
    $ns queue-limit $leaf($i) $hub $opt(queue)
}
$ns duplex-link-op $hub $leaf(1) orient left-down
$ns duplex-link-op $hub $leaf(2) orient right-down
$ns duplex-link-op $hub $leaf(3) orient left-up
$ns duplex-link-op $hub $leaf(4) orient right-up

$ns color 1 Blue
$ns color 2 Red

# ---- traffic -----------------------------------------------------------------
proc make_flow {ns src dst fid} {
    global opt
    if {$opt(traffic) == "tcp"} {
        set agent [new Agent/TCP]
        set sink  [new Agent/TCPSink]
        $agent set packetSize_ $opt(pktsize)
        $agent set fid_ $fid
        $ns attach-agent $src $agent
        $ns attach-agent $dst $sink
        $ns connect $agent $sink
        set app [new Application/FTP]
        $app attach-agent $agent
    } else {
        set agent [new Agent/UDP]
        set sink  [new Agent/Null]
        $agent set fid_ $fid
        $ns attach-agent $src $agent
        $ns attach-agent $dst $sink
        $ns connect $agent $sink
        set app [new Application/Traffic/CBR]
        $app set packetSize_ $opt(pktsize)
        $app set rate_ $opt(rate)
        $app set random_ 0
        $app attach-agent $agent
    }
    $ns at 0.5 "$app start"
    $ns at [expr {$opt(duration) - 0.5}] "$app stop"
}

make_flow $ns $leaf(1) $leaf(3) 1
make_flow $ns $leaf(2) $leaf(4) 2

# ---- run ---------------------------------------------------------------------
$ns at $opt(duration) "finish"
$ns run
