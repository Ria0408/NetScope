# =============================================================================
# NetScope - Topology 2: bottleneck (dumbbell) network (NS-2)
#
#   n0 ---\                                  /--- n4
#          \   access          access       /
#           n2 ================== n3 ------
#          /     bottleneck link           \
#   n1 ---/                                  \--- n5
#
# Access links : abw / adelay  (fast)
# Bottleneck   : bw  / delay   (n2 <-> n3, small queue -> congestion + drops)
# Flow 1: n0 -> n4     Flow 2: n1 -> n5
#
# Run:  ns bottleneck.tcl traffic udp bw 1Mb delay 20ms queue 10 abw 10Mb \
#          adelay 1ms duration 10 rate 1Mb pktsize 1000 trace b.tr nam b.nam
#
# With two 1 Mb CBR flows the offered load (2 Mb) exceeds the 1 Mb bottleneck,
# so the bottleneck queue overflows and packets are dropped.
# =============================================================================

# ---- defaults (override with key/value pairs on the command line) -----------
set opt(traffic)  tcp
set opt(bw)       1Mb
set opt(delay)    20ms
set opt(queue)    10
set opt(abw)      10Mb
set opt(adelay)   1ms
set opt(duration) 10.0
set opt(rate)     1Mb
set opt(pktsize)  1000
set opt(trace)    bottleneck.tr
set opt(nam)      bottleneck.nam

foreach {key value} $argv {
    set opt([string trimleft $key -]) $value
}

if {$opt(traffic) != "tcp" && $opt(traffic) != "udp"} {
    puts stderr "ERROR: traffic must be tcp or udp (got $opt(traffic))"
    exit 1
}

# ---- simulator and trace files ----------------------------------------------
set ns [new Simulator]

set tf [open $opt(trace) w]
$ns trace-all $tf

if {$opt(nam) != "none"} {
    set nf [open $opt(nam) w]
    $ns namtrace-all $nf
}

proc finish {} {
    global ns tf nf opt
    $ns flush-trace
    close $tf
    if {$opt(nam) != "none"} {
        close $nf
    }
    exit 0
}

# ---- nodes n(0)..n(5) -------------------------------------------------------
for {set i 0} {$i < 6} {incr i} {
    set n($i) [$ns node]
}

# ---- links -------------------------------------------------------------------
# access links
$ns duplex-link $n(0) $n(2) $opt(abw) $opt(adelay) DropTail
$ns duplex-link $n(1) $n(2) $opt(abw) $opt(adelay) DropTail
$ns duplex-link $n(3) $n(4) $opt(abw) $opt(adelay) DropTail
$ns duplex-link $n(3) $n(5) $opt(abw) $opt(adelay) DropTail
# bottleneck link
$ns duplex-link $n(2) $n(3) $opt(bw) $opt(delay) DropTail

# queue limits: large on access links, small on the bottleneck
$ns queue-limit $n(0) $n(2) 50
$ns queue-limit $n(1) $n(2) 50
$ns queue-limit $n(3) $n(4) 50
$ns queue-limit $n(3) $n(5) 50
$ns queue-limit $n(2) $n(3) $opt(queue)
$ns queue-limit $n(3) $n(2) $opt(queue)

$ns duplex-link-op $n(0) $n(2) orient right-down
$ns duplex-link-op $n(1) $n(2) orient right-up
$ns duplex-link-op $n(2) $n(3) orient right
$ns duplex-link-op $n(3) $n(4) orient right-up
$ns duplex-link-op $n(3) $n(5) orient right-down

$ns color 1 Blue
$ns color 2 Red

# ---- traffic -----------------------------------------------------------------
proc make_flow {ns src dst fid} {
    global opt
    if {$opt(traffic) == "tcp"} {
        set agent [new Agent/TCP]
        set sink  [new Agent/TCPSink]
        $agent set packetSize_ $opt(pktsize)
        $agent set fid_ $fid
        $ns attach-agent $src $agent
        $ns attach-agent $dst $sink
        $ns connect $agent $sink
        set app [new Application/FTP]
        $app attach-agent $agent
    } else {
        set agent [new Agent/UDP]
        set sink  [new Agent/Null]
        $agent set fid_ $fid
        $ns attach-agent $src $agent
        $ns attach-agent $dst $sink
        $ns connect $agent $sink
        set app [new Application/Traffic/CBR]
        $app set packetSize_ $opt(pktsize)
        $app set rate_ $opt(rate)
        $app set random_ 0
        $app attach-agent $agent
    }
    $ns at 0.5 "$app start"
    $ns at [expr {$opt(duration) - 0.5}] "$app stop"
}

make_flow $ns $n(0) $n(4) 1
make_flow $ns $n(1) $n(5) 2

# ---- run ---------------------------------------------------------------------
$ns at $opt(duration) "finish"
$ns run
