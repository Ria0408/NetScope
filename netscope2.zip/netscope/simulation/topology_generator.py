"""Simulation configuration, validation and Tcl argument generation.

The Tcl scripts (``star_topology.tcl`` / ``bottleneck.tcl``) take ``key value``
pairs on the command line. This module validates the user's configuration and
builds exactly that argument list, and also provides node layouts used by the
dashboard to draw the topology.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import config

_BANDWIDTH_RE = re.compile(r"^\d+(\.\d+)?(b|Kb|Mb|Gb)$")
_DELAY_RE = re.compile(r"^\d+(\.\d+)?(us|ms|s)$")

TOPOLOGIES: Dict[str, Dict[str, object]] = {
    "star": {
        "label": "Five-node Star",
        "script": "star_topology.tcl",
        "flows": [(1, 3), (2, 4)],
        "defaults": {"bw": 2.0, "delay": 10.0, "queue": 20, "rate": 1.0},
        "nodes": {  # id: (x, y, label)
            0: (0.0, 0.0, "n0 (hub)"),
            1: (-1.0, -1.0, "n1"),
            2: (1.0, -1.0, "n2"),
            3: (-1.0, 1.0, "n3"),
            4: (1.0, 1.0, "n4"),
        },
        "edges": [(0, 1), (0, 2), (0, 3), (0, 4)],
        "bottleneck_edges": [],
    },
    "bottleneck": {
        "label": "Bottleneck (dumbbell)",
        "script": "bottleneck.tcl",
        "flows": [(0, 4), (1, 5)],
        "defaults": {"bw": 1.0, "delay": 20.0, "queue": 10, "rate": 1.0},
        "nodes": {
            0: (0.0, 1.0, "n0"),
            1: (0.0, -1.0, "n1"),
            2: (1.0, 0.0, "n2 (router)"),
            3: (3.0, 0.0, "n3 (router)"),
            4: (4.0, 1.0, "n4"),
            5: (4.0, -1.0, "n5"),
        },
        "edges": [(0, 2), (1, 2), (2, 3), (3, 4), (3, 5)],
        "bottleneck_edges": [(2, 3)],
    },
}

TRAFFIC_LABELS = {"tcp": "TCP (FTP traffic)", "udp": "UDP (CBR traffic)"}


@dataclass
class SimulationConfig:
    topology: str = "star"
    traffic: str = "tcp"
    bandwidth: str = "2Mb"          # star: every link; bottleneck: bottleneck link
    delay: str = "10ms"
    queue_limit: int = 20
    duration: float = 10.0
    cbr_rate: str = "1Mb"           # UDP/CBR offered load per flow
    packet_size: int = 1000
    access_bandwidth: str = "10Mb"  # bottleneck topology only
    access_delay: str = "1ms"
    generate_nam: bool = True

    @classmethod
    def for_topology(cls, topology: str, traffic: str = "tcp", **overrides) -> "SimulationConfig":
        """Config pre-filled with the recommended defaults of ``topology``."""
        if topology not in TOPOLOGIES:
            raise ValueError(f"Unknown topology '{topology}'")
        d = TOPOLOGIES[topology]["defaults"]
        values = dict(
            topology=topology, traffic=traffic, bandwidth=f"{d['bw']:g}Mb",
            delay=f"{d['delay']:g}ms", queue_limit=int(d["queue"]), cbr_rate=f"{d['rate']:g}Mb",
        )
        values.update(overrides)
        return cls(**values)

    def validate(self) -> None:
        if self.topology not in TOPOLOGIES:
            raise ValueError(f"Unknown topology '{self.topology}'")
        if self.traffic not in TRAFFIC_LABELS:
            raise ValueError("Traffic must be 'tcp' or 'udp'")
        for name, value in (("bandwidth", self.bandwidth),
                            ("cbr_rate", self.cbr_rate),
                            ("access_bandwidth", self.access_bandwidth)):
            if not _BANDWIDTH_RE.match(str(value)):
                raise ValueError(f"Invalid {name} '{value}' (examples: 500Kb, 2Mb)")
        for name, value in (("delay", self.delay), ("access_delay", self.access_delay)):
            if not _DELAY_RE.match(str(value)):
                raise ValueError(f"Invalid {name} '{value}' (examples: 10ms, 100us)")
        if not 1 <= int(self.queue_limit) <= 10_000:
            raise ValueError("Queue limit must be between 1 and 10000 packets")
        if not 2.0 <= float(self.duration) <= 600.0:
            raise ValueError("Duration must be between 2 and 600 seconds")
        if not 40 <= int(self.packet_size) <= 1500:
            raise ValueError("Packet size must be between 40 and 1500 bytes")


def get_script_path(topology: str) -> Path:
    if topology not in TOPOLOGIES:
        raise ValueError(f"Unknown topology '{topology}'")
    return config.SIMULATION_DIR / str(TOPOLOGIES[topology]["script"])


def build_tcl_args(cfg: SimulationConfig, trace_path: Path, nam_path: Path) -> List[str]:
    """Return the ``key value`` argument list for the Tcl script."""
    cfg.validate()
    args = [
        "traffic", cfg.traffic,
        "bw", cfg.bandwidth,
        "delay", cfg.delay,
        "queue", str(int(cfg.queue_limit)),
        "duration", f"{float(cfg.duration):g}",
        "rate", cfg.cbr_rate,
        "pktsize", str(int(cfg.packet_size)),
        "trace", str(trace_path),
        "nam", str(nam_path) if cfg.generate_nam else "none",
    ]
    if cfg.topology == "bottleneck":
        args += ["abw", cfg.access_bandwidth, "adelay", cfg.access_delay]
    return args


def get_layout(topology: str) -> Tuple[Dict[int, Tuple[float, float, str]], List[Tuple[int, int]], List[Tuple[int, int]], List[Tuple[int, int]]]:
    """Return ``(nodes, edges, bottleneck_edges, flows)`` for drawing."""
    spec = TOPOLOGIES[topology]
    return (
        spec["nodes"],  # type: ignore[return-value]
        spec["edges"],  # type: ignore[return-value]
        spec["bottleneck_edges"],  # type: ignore[return-value]
        spec["flows"],  # type: ignore[return-value]
    )
