"""Network performance formulas and metric helpers.

Formulas (from the project specification):
    Throughput  = (Total Bytes x 8) / Time Interval
    PDR         = (Packets Received / Packets Sent) x 100
    Packet Loss = ((Packets Sent - Packets Received) / Packets Sent) x 100
    Avg Delay   = Total Packet Delay / Number of Received Packets
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd


def throughput_bps(total_bytes: float, interval_s: float) -> float:
    """Throughput in bits per second."""
    if not interval_s or interval_s <= 0:
        return 0.0
    return (total_bytes * 8.0) / interval_s


def packets_per_second(packet_count: float, interval_s: float) -> float:
    if not interval_s or interval_s <= 0:
        return 0.0
    return packet_count / interval_s


def packet_delivery_ratio(received: int, sent: int) -> float:
    """PDR in percent."""
    if sent <= 0:
        return 0.0
    return (received / sent) * 100.0


def packet_loss_percent(sent: int, received: int) -> float:
    """Packet loss in percent."""
    if sent <= 0:
        return 0.0
    return ((sent - received) / sent) * 100.0


def average_delay(total_delay_s: float, received: int) -> float:
    """Average end-to-end delay in seconds."""
    if received <= 0:
        return 0.0
    return total_delay_s / received


def format_bytes(num_bytes: float) -> str:
    value = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if abs(value) < 1024.0:
            return f"{value:.0f} {unit}" if unit == "B" else f"{value:.2f} {unit}"
        value /= 1024.0
    return f"{value:.2f} TB"


def format_bps(bits_per_second: float) -> str:
    value = float(bits_per_second)
    for unit in ("bps", "Kbps", "Mbps", "Gbps"):
        if abs(value) < 1000.0:
            return f"{value:.2f} {unit}"
        value /= 1000.0
    return f"{value:.2f} Tbps"


def dataset_metrics(
    total_packets: int,
    total_bytes: int,
    first_ts: Optional[float],
    last_ts: Optional[float],
) -> Dict[str, float]:
    """Observed metrics for a packet capture (no loss/delay: a PCAP alone
    does not contain sender/receiver pairing)."""
    duration = 0.0
    if first_ts is not None and last_ts is not None:
        duration = max(0.0, last_ts - first_ts)
    return {
        "total_packets": int(total_packets),
        "total_bytes": int(total_bytes),
        "duration_s": duration,
        "throughput_bps": throughput_bps(total_bytes, duration),
        "packets_per_second": packets_per_second(total_packets, duration),
        "avg_packet_size": (total_bytes / total_packets) if total_packets else 0.0,
    }


def compute_flow_metrics(table: pd.DataFrame, dropped: int = 0) -> Dict[str, float]:
    """Metrics for a delivery table (see ``trace_parser.build_delivery_table``).

    Expected columns: size, recv_size, send_time, recv_time, delivered, delay.
    Interval = first packet sent -> last packet received.
    """
    sent = int(len(table))
    delivered = table[table["delivered"]] if sent else table
    received = int(len(delivered))
    bytes_sent = int(table["size"].sum()) if sent else 0
    bytes_received = int(delivered["recv_size"].sum()) if received else 0

    interval = 0.0
    total_delay = 0.0
    if received:
        interval = float(delivered["recv_time"].max() - table["send_time"].min())
        total_delay = float(delivered["delay"].sum())

    avg_delay_s = average_delay(total_delay, received)
    return {
        "packets_sent": sent,
        "packets_received": received,
        "packets_dropped": int(dropped),
        "packets_lost": sent - received,
        "bytes_sent": bytes_sent,
        "bytes_received": bytes_received,
        "interval_s": interval,
        "throughput_bps": throughput_bps(bytes_received, interval),
        "packets_per_second": packets_per_second(received, interval),
        "pdr_percent": packet_delivery_ratio(received, sent),
        "loss_percent": packet_loss_percent(sent, received),
        "avg_delay_s": avg_delay_s,
        "avg_delay_ms": avg_delay_s * 1000.0,
    }


def throughput_timeseries(
    table: pd.DataFrame, bin_s: float = 0.5, aggregate: bool = False
) -> pd.DataFrame:
    """Received throughput (kbps) per time bin.

    Returns columns ``time, flow, throughput_kbps`` (one series per flow), or
    ``time, throughput_kbps`` when ``aggregate`` is True.
    """
    cols = ["time", "throughput_kbps"] if aggregate else ["time", "flow", "throughput_kbps"]
    delivered = table[table["delivered"]] if len(table) else table
    if delivered.empty:
        return pd.DataFrame(columns=cols)

    work = delivered.assign(bin_idx=(delivered["recv_time"] // bin_s).astype(int))
    grouped = work.groupby(["fid", "bin_idx"])["recv_size"].sum().unstack(0)
    grouped = grouped.reindex(range(0, int(work["bin_idx"].max()) + 1)).fillna(0.0)
    kbps = grouped * (8.0 / bin_s / 1000.0)
    kbps.index = kbps.index * bin_s
    kbps.index.name = "time"

    if aggregate:
        out = kbps.sum(axis=1).rename("throughput_kbps").reset_index()
        return out[cols]
    kbps.columns = [f"Flow {int(c)}" for c in kbps.columns]
    out = kbps.reset_index().melt(id_vars="time", var_name="flow", value_name="throughput_kbps")
    return out[cols]
