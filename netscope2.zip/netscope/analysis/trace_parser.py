"""Parse NS-2 trace files (old/wired format) with Pandas, plus an AWK cross-check.

Old trace line:
    event time from to type size flags fid src dst seq pkt_id
    r     1.2  1    3  cbr  1000 ------- 1   0.0 3.0 0   17

Definitions used for the end-to-end metrics (data packets only: tcp, cbr):
    sent      first-hop enqueue ('+') where from_node == source node
    received  last-hop receive ('r') where to_node == destination node
    dropped   any 'd' event
    delay     receive time - send time of the same packet id
"""
from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Union

import pandas as pd

import config
from analysis import metrics

logger = logging.getLogger(__name__)

TRACE_COLUMNS = [
    "event", "time", "from_node", "to_node", "pkt_type", "size",
    "flags", "fid", "src_addr", "dst_addr", "seq", "pkt_id",
]
DATA_TYPES = ("tcp", "cbr")
AWK_SCRIPT = config.ANALYSIS_DIR / "trace_summary.awk"


class TraceParseError(ValueError):
    """Raised when a trace file is missing, empty or malformed."""


def parse_trace(path: Union[str, Path]) -> pd.DataFrame:
    """Read an NS-2 trace into a DataFrame with typed columns."""
    path = Path(path)
    if not path.is_file():
        raise TraceParseError(f"Trace file not found: {path}")
    if path.stat().st_size == 0:
        raise TraceParseError(f"Trace file is empty: {path.name}")
    try:
        df = pd.read_csv(
            path,
            sep=r"\s+",
            header=None,
            names=TRACE_COLUMNS,
            usecols=range(len(TRACE_COLUMNS)),
            index_col=False,
            dtype={"event": str, "pkt_type": str, "flags": str,
                   "src_addr": str, "dst_addr": str},
            on_bad_lines="skip",
        )
    except Exception as exc:
        raise TraceParseError(f"Could not parse {path.name}: {exc}") from exc

    df = df.dropna(subset=["event", "time", "from_node", "to_node", "pkt_type", "pkt_id"])
    df = df[df["event"].isin(["+", "-", "r", "d"])].copy()
    if df.empty:
        raise TraceParseError(f"{path.name} contains no NS-2 trace events.")

    for col in ("time",):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in ("from_node", "to_node", "size", "fid", "pkt_id"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["time", "from_node", "to_node", "size", "fid", "pkt_id"])
    for col in ("from_node", "to_node", "size", "fid", "pkt_id"):
        df[col] = df[col].astype(int)

    df["src_node"] = df["src_addr"].str.split(".").str[0].astype(int)
    df["dst_node"] = df["dst_addr"].str.split(".").str[0].astype(int)
    return df.reset_index(drop=True)


def build_delivery_table(trace: pd.DataFrame) -> pd.DataFrame:
    """One row per data packet sent, with receive time / delay when delivered."""
    data = trace[trace["pkt_type"].isin(DATA_TYPES)]
    sent = data[(data["event"] == "+") & (data["from_node"] == data["src_node"])]
    sent = sent[["pkt_id", "fid", "pkt_type", "size", "time", "src_node", "dst_node"]]
    sent = sent.rename(columns={"time": "send_time"}).drop_duplicates("pkt_id")

    received = data[(data["event"] == "r") & (data["to_node"] == data["dst_node"])]
    received = received[["pkt_id", "time", "size"]]
    received = received.rename(columns={"time": "recv_time", "size": "recv_size"})
    received = received.drop_duplicates("pkt_id")

    table = sent.merge(received, on="pkt_id", how="left")
    table["delivered"] = table["recv_time"].notna()
    table["delay"] = table["recv_time"] - table["send_time"]
    return table.reset_index(drop=True)


def analyze_trace(path: Union[str, Path]) -> Dict[str, object]:
    """Compute overall and per-flow metrics for a trace file."""
    trace = parse_trace(path)
    table = build_delivery_table(trace)
    if table.empty:
        raise TraceParseError("Trace has no data packets (tcp/cbr) sent by a source node.")

    drops = trace[(trace["event"] == "d") & trace["pkt_type"].isin(DATA_TYPES)]
    overall = metrics.compute_flow_metrics(table, dropped=len(drops))

    flows: List[Dict[str, object]] = []
    for fid, group in table.groupby("fid"):
        flow_drops = int((drops["fid"] == fid).sum())
        row = metrics.compute_flow_metrics(group, dropped=flow_drops)
        row.update({
            "flow_id": int(fid),
            "src_node": int(group["src_node"].iloc[0]),
            "dst_node": int(group["dst_node"].iloc[0]),
            "pkt_type": str(group["pkt_type"].iloc[0]),
        })
        flows.append(row)

    logger.info(
        "Analyzed %s: sent=%d received=%d dropped=%d",
        Path(path).name, overall["packets_sent"], overall["packets_received"],
        overall["packets_dropped"],
    )
    return {"overall": overall, "flows": flows}


def load_timeseries(
    path: Union[str, Path], bin_s: float = 0.5, aggregate: bool = False
) -> pd.DataFrame:
    """Received-throughput time series (kbps) straight from a trace file."""
    table = build_delivery_table(parse_trace(path))
    return metrics.throughput_timeseries(table, bin_s=bin_s, aggregate=aggregate)


def awk_summary(path: Union[str, Path]) -> Optional[Dict[str, float]]:
    """Run ``trace_summary.awk`` and return its counts, or None if awk is missing."""
    awk = shutil.which("awk") or shutil.which("gawk")
    if awk is None or not AWK_SCRIPT.is_file():
        return None
    try:
        proc = subprocess.run(
            [awk, "-f", str(AWK_SCRIPT), str(path)],
            capture_output=True, text=True, timeout=60, check=True,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        logger.warning("AWK summary failed: %s", exc)
        return None
    result: Dict[str, float] = {}
    for token in proc.stdout.split():
        key, _, value = token.partition("=")
        result[key] = float(value)
    return result


def awk_matches(summary: Dict[str, object], awk: Optional[Dict[str, float]]) -> Optional[bool]:
    """True if the AWK counts agree with the Pandas analysis (None if no AWK)."""
    if awk is None:
        return None
    return (
        int(awk["sent"]) == summary["packets_sent"]
        and int(awk["received"]) == summary["packets_received"]
        and int(awk["dropped"]) == summary["packets_dropped"]
        and abs(awk["avg_delay"] - summary["avg_delay_s"]) < 1e-6
    )
