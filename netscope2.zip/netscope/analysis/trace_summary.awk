# NetScope - AWK summary of an NS-2 trace (old trace format).
# Used as an independent cross-check of the Python/Pandas analysis.
#
# Columns: 1 event  2 time  3 from  4 to  5 type  6 size  7 flags
#          8 fid    9 src   10 dst   11 seq 12 pkt_id
#
# sent     = data packet enqueued ('+') on the first hop (from == source node)
# received = data packet received ('r') on the last hop (to == destination node)
# dropped  = data packet dropped ('d') anywhere in the network
#
# Usage: awk -f trace_summary.awk trace.tr

function node(addr,    parts) {
    split(addr, parts, ".")
    return parts[1]
}

BEGIN { sent = 0; recv = 0; drop = 0; delay = 0; bytes = 0 }

($5 == "tcp" || $5 == "cbr") {
    if ($1 == "+" && $3 == node($9)) {
        sent++
        send_time[$12] = $2
    } else if ($1 == "r" && $4 == node($10)) {
        if ($12 in send_time) {
            recv++
            bytes += $6
            delay += $2 - send_time[$12]
        }
    } else if ($1 == "d") {
        drop++
    }
}

END {
    avg = (recv > 0) ? delay / recv : 0
    printf "sent=%d received=%d dropped=%d bytes_received=%d avg_delay=%.9f\n", \
           sent, recv, drop, bytes, avg
}
