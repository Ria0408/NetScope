"""Turn a Scapy packet into a flat, JSON-friendly record.

HTTPS/TLS traffic is only *identified* (port / TLS record header); it is never
decrypted.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from scapy.layers.dns import DNS
from scapy.layers.inet import ICMP, IP, TCP, UDP
from scapy.layers.inet6 import IPv6
from scapy.layers.l2 import ARP
from scapy.packet import Packet

RECORD_COLUMNS = [
    "number",
    "timestamp",
    "src_ip",
    "dst_ip",
    "src_port",
    "dst_port",
    "protocol",
    "length",
    "tcp_flags",
]

PROTOCOLS = ["TCP", "UDP", "DNS", "ICMP", "HTTP", "HTTPS/TLS", "Other"]

DNS_PORT = 53
HTTP_PORTS = {80, 8000, 8080}
TLS_PORTS = {443, 8443}
_HTTP_PREFIXES = (
    b"GET ", b"POST ", b"PUT ", b"HEAD ", b"DELETE ", b"OPTIONS ", b"PATCH ", b"HTTP/",
)
_IPV6_ICMP = 58


def _looks_like_tls(payload: bytes) -> bool:
    """TLS record header: type 20-23, major version 3, minor version 0-4."""
    return (
        len(payload) >= 3
        and payload[0] in (0x14, 0x15, 0x16, 0x17)
        and payload[1] == 0x03
        and payload[2] <= 0x04
    )


def _looks_like_http(payload: bytes) -> bool:
    return payload.startswith(_HTTP_PREFIXES)


def classify_protocol(
    pkt: Packet,
    transport: Optional[str],
    sport: Optional[int],
    dport: Optional[int],
    payload: bytes,
    is_icmp: bool,
) -> str:
    """Return one of ``PROTOCOLS`` for the packet."""
    ports = {p for p in (sport, dport) if p is not None}
    if pkt.haslayer(DNS) or (transport and DNS_PORT in ports):
        return "DNS"
    if is_icmp:
        return "ICMP"
    if transport == "TCP":
        if _looks_like_tls(payload) or ports & TLS_PORTS:
            return "HTTPS/TLS"
        if _looks_like_http(payload) or ports & HTTP_PORTS:
            return "HTTP"
        return "TCP"
    if transport == "UDP":
        return "UDP"
    return "Other"


def parse_packet(pkt: Packet, number: int) -> Dict[str, Any]:
    """Extract the fields required by the project from one packet."""
    src_ip = dst_ip = None
    is_icmp = pkt.haslayer(ICMP)

    if pkt.haslayer(IP):
        ip = pkt[IP]
        src_ip, dst_ip = ip.src, ip.dst
    elif pkt.haslayer(IPv6):
        ip6 = pkt[IPv6]
        src_ip, dst_ip = ip6.src, ip6.dst
        is_icmp = is_icmp or ip6.nh == _IPV6_ICMP
    elif pkt.haslayer(ARP):
        arp = pkt[ARP]
        src_ip, dst_ip = arp.psrc, arp.pdst

    transport: Optional[str] = None
    sport = dport = None
    flags: Optional[str] = None
    payload = b""
    if pkt.haslayer(TCP):
        layer = pkt[TCP]
        transport = "TCP"
        sport, dport = int(layer.sport), int(layer.dport)
        flags = str(layer.flags)
        payload = bytes(layer.payload)[:16]
    elif pkt.haslayer(UDP):
        layer = pkt[UDP]
        transport = "UDP"
        sport, dport = int(layer.sport), int(layer.dport)

    protocol = classify_protocol(pkt, transport, sport, dport, payload, is_icmp)
    length = int(getattr(pkt, "wirelen", None) or len(pkt))

    return {
        "number": number,
        "timestamp": float(pkt.time),
        "src_ip": src_ip,
        "dst_ip": dst_ip,
        "src_port": sport,
        "dst_port": dport,
        "protocol": protocol,
        "length": length,
        "tcp_flags": flags,
    }
