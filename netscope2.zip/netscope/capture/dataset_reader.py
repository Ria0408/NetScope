"""Validation and memory-efficient reading of PCAP / PCAPNG datasets.

Packets are streamed one at a time with Scapy's ``PcapReader`` (a generator),
so a large capture is never loaded into memory as a whole.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Dict, Iterator, List, Tuple, Union

from scapy.packet import Packet
from scapy.utils import PcapReader, RawPcapReader

import config
from analysis.metrics import format_bytes

logger = logging.getLogger(__name__)

ALLOWED_EXTENSIONS = (".pcap", ".pcapng")
_PCAP_MAGICS = {
    bytes.fromhex(h) for h in ("d4c3b2a1", "a1b2c3d4", "4d3cb2a1", "a1b23c4d")
}
_PCAPNG_MAGIC = bytes.fromhex("0a0d0d0a")
_MIN_FILE_SIZE = 24  # size of a classic pcap global header


class InvalidCaptureError(ValueError):
    """Raised when a file is not a readable PCAP / PCAPNG capture."""


def detect_format(path: Union[str, Path]) -> str:
    """Validate ``path`` and return ``"pcap"`` or ``"pcapng"`` (from magic bytes)."""
    path = Path(path)
    if not path.is_file():
        raise InvalidCaptureError(f"File not found: {path.name}")
    if path.suffix.lower() not in ALLOWED_EXTENSIONS:
        raise InvalidCaptureError(
            f"Unsupported file type '{path.suffix}'. Upload a .pcap or .pcapng file."
        )
    if path.stat().st_size < _MIN_FILE_SIZE:
        raise InvalidCaptureError(f"{path.name} is empty or too small to be a capture.")
    with open(path, "rb") as handle:
        magic = handle.read(4)
    if magic in _PCAP_MAGICS:
        return "pcap"
    if magic == _PCAPNG_MAGIC:
        return "pcapng"
    raise InvalidCaptureError(
        f"{path.name} is not a valid PCAP/PCAPNG file (bad file signature)."
    )


def iter_packets(path: Union[str, Path]) -> Iterator[Tuple[int, Packet]]:
    """Yield ``(packet_number, scapy_packet)`` lazily; numbering starts at 1."""
    path = Path(path)
    fmt = detect_format(path)
    try:
        with PcapReader(str(path)) as reader:
            for number, packet in enumerate(reader, start=1):
                yield number, packet
    except InvalidCaptureError:
        raise
    except Exception as exc:  # Scapy raises several unrelated exception types
        raise InvalidCaptureError(f"Could not read {path.name} as {fmt}: {exc}") from exc


def count_packets(path: Union[str, Path]) -> int:
    """Count packets without dissecting them (fast, constant memory)."""
    path = Path(path)
    fmt = detect_format(path)
    try:
        count = 0
        with RawPcapReader(str(path)) as reader:
            for _ in reader:
                count += 1
        return count
    except Exception as exc:
        raise InvalidCaptureError(f"Could not read {path.name} as {fmt}: {exc}") from exc


def get_dataset_info(path: Union[str, Path]) -> Dict[str, object]:
    """Return filename, size, format and packet count for the dataset."""
    path = Path(path)
    fmt = detect_format(path)
    size = path.stat().st_size
    packets = count_packets(path)
    logger.info("Dataset %s: %s, %d packets, %s", path.name, fmt, packets, format_bytes(size))
    return {
        "filename": path.name,
        "size_bytes": size,
        "size_human": format_bytes(size),
        "format": fmt,
        "packets": packets,
    }


def _safe_name(name: str) -> str:
    base = Path(name).name
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", base)
    return cleaned or "capture.pcap"


def save_uploaded_file(name: str, data, dest_dir: Union[str, Path, None] = None) -> Path:
    """Persist uploaded bytes to disk, validate them, and return the saved path.

    ``data`` may be bytes, a memoryview (Streamlit ``getbuffer``) or a binary
    file object. An invalid upload is deleted before the error is raised.
    """
    directory = Path(dest_dir) if dest_dir else config.UPLOAD_DIR
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / _safe_name(name)
    if target.suffix.lower() not in ALLOWED_EXTENSIONS:
        raise InvalidCaptureError(
            f"Unsupported file type '{target.suffix}'. Upload a .pcap or .pcapng file."
        )
    with open(target, "wb") as out:
        if hasattr(data, "read"):
            while True:
                chunk = data.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
        else:
            out.write(data)
    try:
        detect_format(target)
    except InvalidCaptureError:
        target.unlink(missing_ok=True)
        raise
    logger.info("Saved upload %s (%s)", target.name, format_bytes(target.stat().st_size))
    return target


def list_datasets(directory: Union[str, Path, None] = None) -> List[Path]:
    """Return previously uploaded datasets, newest first."""
    folder = Path(directory) if directory else config.UPLOAD_DIR
    if not folder.is_dir():
        return []
    files = [p for p in folder.iterdir() if p.suffix.lower() in ALLOWED_EXTENSIONS]
    return sorted(files, key=lambda p: p.stat().st_mtime, reverse=True)
