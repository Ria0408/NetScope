"""Generate a small synthetic PCAP for demos/tests (no real network traffic).

Usage:  python tools/make_sample_pcap.py data/sample.pcap [packet_count]
"""
from __future__ import annotations

import random
import sys
from pathlib import Path

from scapy.layers.dns import DNS, DNSQR
from scapy.layers.inet import ICMP, IP, TCP, UDP
from scapy.layers.l2 import ARP, Ether
from scapy.packet import Raw
from scapy.utils import wrpcap

CLIENTS = ["192.168.1.10", "192.168.1.11", "192.168.1.12"]
SERVERS = ["93.184.216.34", "142.250.183.14", "151.101.1.69", "8.8.8.8"]


def make_sample_packets(count: int = 500, seed: int = 1):
    rng = random.Random(seed)
    packets = []
    ts = 1_700_000_000.0
    for i in range(count):
        client = rng.choice(CLIENTS)
        server = rng.choice(SERVERS)
        sport = rng.randint(20000, 60000)
        kind = rng.choice(["http", "tls", "tls", "dns", "icmp", "udp", "syn", "arp"])
        eth = Ether()
        if kind == "http":
            pkt = eth / IP(src=client, dst=server) / TCP(sport=sport, dport=80, flags="PA") / Raw(
                b"GET /index.html HTTP/1.1\r\nHost: example.com\r\n\r\n")
        elif kind == "tls":
            pkt = eth / IP(src=client, dst=server) / TCP(sport=sport, dport=443, flags="PA") / Raw(
                b"\x16\x03\x01\x00\x30" + bytes(rng.randint(0, 255) for _ in range(rng.randint(40, 900))))
        elif kind == "dns":
            pkt = eth / IP(src=client, dst="8.8.8.8") / UDP(sport=sport, dport=53) / DNS(
                rd=1, qd=DNSQR(qname="example.com"))
        elif kind == "icmp":
            pkt = eth / IP(src=client, dst=server) / ICMP() / Raw(b"x" * rng.randint(8, 100))
        elif kind == "udp":
            pkt = eth / IP(src=client, dst=server) / UDP(sport=sport, dport=rng.choice([123, 5004, 9999])) / Raw(
                b"d" * rng.randint(20, 600))
        elif kind == "syn":
            pkt = eth / IP(src=client, dst=server) / TCP(sport=sport, dport=rng.choice([22, 25, 8081]), flags="S")
        else:
            pkt = eth / ARP(psrc=client, pdst=rng.choice(CLIENTS))
        ts += rng.random() * 0.05
        pkt.time = ts
        packets.append(pkt)
    return packets


def make_sample_pcap(path, count: int = 500, seed: int = 1) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wrpcap(str(path), make_sample_packets(count, seed))
    return path


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "data/sample.pcap"
    number = int(sys.argv[2]) if len(sys.argv) > 2 else 500
    print(f"Wrote {number} packets to {make_sample_pcap(target, number)}")
