import threading
import time
from collections import Counter

import pytest

from capture.dataset_reader import iter_packets
from capture.packet_parser import parse_packet
from processing.analytics import TrafficStats, apply_filters
from processing.packet_queue import END, PacketQueue
from processing.thread_manager import (
    STATUS_COMPLETED, STATUS_FAILED, STATUS_STOPPED, AnalysisPipeline, run_analysis,
)
from tools.make_sample_pcap import make_sample_pcap

N = 400


@pytest.fixture(scope="module")
def pcap(tmp_path_factory):
    return make_sample_pcap(tmp_path_factory.mktemp("pcap") / "sample.pcap", N)


def test_pipeline_matches_sequential_processing(pcap):
    expected = [parse_packet(p, n) for n, p in iter_packets(pcap)]
    result = run_analysis(pcap, queue_size=16)
    stats = result["stats"]
    assert result["status"] == STATUS_COMPLETED and not result["errors"]
    assert stats["total_packets"] == N == len(result["dataframe"])
    assert stats["total_bytes"] == sum(r["length"] for r in expected)
    assert stats["protocol_counts"] == dict(Counter(r["protocol"] for r in expected))
    assert sum(stats["protocol_counts"].values()) == N
    assert result["counts"] == {"read": N, "parsed": N, "stored": N, "malformed": 0}
    assert sum(b["packets"] for b in stats["size_histogram"]) == N
    assert sum(t["packets"] for t in stats["timeline"]) == N
    # records arrive in order through the single-consumer chain
    assert list(result["dataframe"]["number"]) == list(range(1, N + 1))


def test_three_distinct_threads_really_run(pcap):
    idents = {}
    names = set()

    def reader_fn(path):
        idents.setdefault("reader", set()).add(threading.get_ident())
        yield from iter_packets(path)

    def parse_fn(pkt, number):
        idents.setdefault("processor", set()).add(threading.get_ident())
        time.sleep(0.002)  # keep the pipeline busy so we can observe it
        return parse_packet(pkt, number)

    class RecordingStats(TrafficStats):
        def update(self, record):
            idents.setdefault("stats", set()).add(threading.get_ident())
            super().update(record)

    pipeline = AnalysisPipeline(pcap, queue_size=8, parse_fn=parse_fn,
                                reader_fn=reader_fn, stats=RecordingStats())
    pipeline.start()
    time.sleep(0.2)
    assert pipeline.is_running()
    live = {t.name for t in threading.enumerate()}
    assert set(AnalysisPipeline.THREAD_NAMES) <= live
    assert pipeline.join(timeout=60)
    assert pipeline.result()["status"] == STATUS_COMPLETED

    all_ids = [next(iter(v)) for v in idents.values()]
    assert set(idents) == {"reader", "processor", "stats"}
    assert all(len(v) == 1 for v in idents.values())
    assert len(set(all_ids)) == 3
    assert threading.get_ident() not in all_ids
    # threads are gone afterwards
    assert not ({t.name for t in threading.enumerate()} & set(AnalysisPipeline.THREAD_NAMES))


def test_backpressure_bounds_queues(pcap):
    peak = {"raw": 0}

    def slow_parse(pkt, number):
        peak["raw"] = max(peak["raw"], pipeline.raw_queue.qsize())
        time.sleep(0.001)
        return parse_packet(pkt, number)

    pipeline = AnalysisPipeline(pcap, queue_size=5, parse_fn=slow_parse)
    pipeline.start()
    assert pipeline.join(timeout=60)
    assert peak["raw"] <= 5
    assert pipeline.result()["stats"]["total_packets"] == N


def test_graceful_stop(pcap):
    def slow_parse(pkt, number):
        time.sleep(0.01)
        return parse_packet(pkt, number)

    pipeline = AnalysisPipeline(pcap, queue_size=4, parse_fn=slow_parse).start()
    time.sleep(0.15)
    pipeline.stop()
    assert pipeline.join(timeout=10), "threads did not terminate after stop()"
    result = pipeline.result()
    assert result["status"] == STATUS_STOPPED
    assert 0 < result["stats"]["total_packets"] < N
    assert not ({t.name for t in threading.enumerate()} & set(AnalysisPipeline.THREAD_NAMES))


def test_reader_error_is_reported_not_raised(tmp_path):
    result = run_analysis(tmp_path / "missing.pcap")
    assert result["status"] == STATUS_FAILED
    assert result["errors"] and "reader" in result["errors"][0]
    assert result["stats"]["total_packets"] == 0


def test_malformed_packets_are_skipped(pcap):
    def flaky(pkt, number):
        if number % 10 == 0:
            raise ValueError("boom")
        return parse_packet(pkt, number)

    result = run_analysis(pcap, parse_fn=flaky)
    assert result["status"] == STATUS_COMPLETED
    assert result["counts"]["malformed"] == N // 10
    assert result["stats"]["total_packets"] == N - N // 10


def test_record_cap_does_not_affect_statistics(pcap):
    result = run_analysis(pcap, max_records=50)
    assert result["truncated"] is True
    assert len(result["dataframe"]) == 50
    assert result["stats"]["total_packets"] == N


def test_processor_failure_stops_pipeline(pcap):
    class BrokenStats(TrafficStats):
        def update(self, record):
            raise RuntimeError("stats exploded")

    pipeline = AnalysisPipeline(pcap, queue_size=4, stats=BrokenStats()).start()
    assert pipeline.join(timeout=10), "pipeline deadlocked after a fatal thread error"
    result = pipeline.result()
    assert result["status"] == STATUS_FAILED
    assert any("stats exploded" in e for e in result["errors"])


def test_trafficstats_has_no_lost_updates():
    stats = TrafficStats()
    workers, per_worker = 8, 2000
    record = {"length": 100, "timestamp": 1.0, "protocol": "TCP",
              "src_ip": "1.1.1.1", "dst_ip": "2.2.2.2"}
    barrier = threading.Barrier(workers)

    def work():
        barrier.wait()
        for _ in range(per_worker):
            stats.update(record)
            stats.snapshot()  # concurrent readers must not corrupt anything

    threads = [threading.Thread(target=work) for _ in range(workers)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    snap = stats.snapshot()
    assert snap["total_packets"] == workers * per_worker
    assert snap["total_bytes"] == workers * per_worker * 100
    assert snap["protocol_counts"] == {"TCP": workers * per_worker}


def test_packet_queue_end_and_stop():
    stop = threading.Event()
    q = PacketQueue(2, stop, poll_interval=0.01)
    assert q.put(1) and q.put(2)
    assert q.get() == 1 and q.get() == 2
    q.close()
    assert q.get() is END
    # full queue + stop -> put returns False instead of blocking forever
    q.put("a"), q.put("b")
    stop.set()
    assert q.put("c") is False
    assert q.get() == "a" and q.get() == "b"
    assert q.get() is None


def test_filters(pcap):
    df = run_analysis(pcap)["dataframe"]
    dns = apply_filters(df, protocols=["DNS"])
    assert len(dns) > 0 and set(dns["protocol"]) == {"DNS"}
    by_port = apply_filters(df, port=443)
    assert len(by_port) > 0 and ((by_port["src_port"] == 443) | (by_port["dst_port"] == 443)).all()
    by_ip = apply_filters(df, src_ip="192.168.1.10", dst_ip="8.8.8.8")
    assert (by_ip["src_ip"] == "192.168.1.10").all() and (by_ip["dst_ip"] == "8.8.8.8").all()
    assert len(apply_filters(df)) == len(df)
