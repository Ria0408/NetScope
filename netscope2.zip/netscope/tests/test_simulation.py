import pytest

from simulation.ns2_runner import find_ns2_binary, run_and_analyze
from simulation.topology_generator import SimulationConfig, build_tcl_args, get_script_path


def test_config_validation():
    SimulationConfig().validate()
    for bad in (
        dict(topology="ring"), dict(traffic="icmp"), dict(bandwidth="fast"),
        dict(delay="10"), dict(queue_limit=0), dict(duration=1), dict(packet_size=10),
        dict(cbr_rate="1; rm -rf /"),
    ):
        with pytest.raises(ValueError):
            SimulationConfig(**bad).validate()


def test_tcl_args(tmp_path):
    args = build_tcl_args(SimulationConfig.for_topology("bottleneck", "udp"),
                          tmp_path / "a.tr", tmp_path / "a.nam")
    pairs = dict(zip(args[::2], args[1::2]))
    assert pairs["traffic"] == "udp" and pairs["bw"] == "1Mb" and pairs["abw"] == "10Mb"
    assert pairs["trace"].endswith("a.tr") and pairs["nam"].endswith("a.nam")
    star = build_tcl_args(SimulationConfig(generate_nam=False), tmp_path / "s.tr", tmp_path / "s.nam")
    assert "abw" not in star and dict(zip(star[::2], star[1::2]))["nam"] == "none"
    assert get_script_path("star").is_file() and get_script_path("bottleneck").is_file()


@pytest.mark.skipif(find_ns2_binary() is None, reason="NS-2 not installed")
@pytest.mark.parametrize("topology", ["star", "bottleneck"])
def test_real_ns2_runs_and_tcp_udp_differ(topology):
    tcp = run_and_analyze(SimulationConfig.for_topology(topology, "tcp", duration=6))
    udp = run_and_analyze(SimulationConfig.for_topology(topology, "udp", duration=6))
    for result in (tcp, udp):
        o = result["overall"]
        assert o["packets_sent"] > 0 and o["packets_received"] > 0
        assert o["pdr_percent"] + o["loss_percent"] == pytest.approx(100.0)
        assert result["awk_consistent"] in (True, None)
    assert tcp["overall"] != udp["overall"]
    if topology == "bottleneck":
        # two 1 Mb CBR flows into a 1 Mb bottleneck must lose packets
        assert udp["overall"]["packets_dropped"] > 0
        assert udp["overall"]["loss_percent"] > 10
        assert udp["overall"]["throughput_bps"] <= 1.05e6
