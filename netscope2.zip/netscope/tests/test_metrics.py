import shutil

import pytest

from analysis import metrics, trace_parser

# Path 0 -> 1 -> 3 (source node 0, destination node 3). Packets:
#   0: delivered, delay 0.2   1: delivered, delay 0.3
#   2: dropped at first hop   3: delivered, delay 0.1
# plus an ACK that must be ignored.
TRACE = """\
+ 1.0 0 1 cbr 1000 ------- 1 0.0 3.0 0 0
- 1.0 0 1 cbr 1000 ------- 1 0.0 3.0 0 0
r 1.1 0 1 cbr 1000 ------- 1 0.0 3.0 0 0
+ 1.1 1 3 cbr 1000 ------- 1 0.0 3.0 0 0
- 1.1 1 3 cbr 1000 ------- 1 0.0 3.0 0 0
r 1.2 1 3 cbr 1000 ------- 1 0.0 3.0 0 0
+ 2.0 0 1 cbr 1000 ------- 1 0.0 3.0 1 1
- 2.0 0 1 cbr 1000 ------- 1 0.0 3.0 1 1
r 2.1 0 1 cbr 1000 ------- 1 0.0 3.0 1 1
+ 2.1 1 3 cbr 1000 ------- 1 0.0 3.0 1 1
- 2.1 1 3 cbr 1000 ------- 1 0.0 3.0 1 1
r 2.3 1 3 cbr 1000 ------- 1 0.0 3.0 1 1
+ 3.0 0 1 cbr 1000 ------- 1 0.0 3.0 2 2
d 3.1 0 1 cbr 1000 ------- 1 0.0 3.0 2 2
+ 4.0 0 1 cbr 1000 ------- 1 0.0 3.0 3 3
- 4.0 0 1 cbr 1000 ------- 1 0.0 3.0 3 3
r 4.05 0 1 cbr 1000 ------- 1 0.0 3.0 3 3
+ 4.05 1 3 cbr 1000 ------- 1 0.0 3.0 3 3
- 4.05 1 3 cbr 1000 ------- 1 0.0 3.0 3 3
r 4.1 1 3 cbr 1000 ------- 1 0.0 3.0 3 3
+ 4.2 3 1 ack 40 ------- 1 3.0 0.0 0 9
r 4.3 3 1 ack 40 ------- 1 3.0 0.0 0 9
"""


@pytest.fixture()
def trace_file(tmp_path):
    path = tmp_path / "t.tr"
    path.write_text(TRACE)
    return path


def test_formulas():
    assert metrics.throughput_bps(1000, 2) == pytest.approx(4000.0)
    assert metrics.throughput_bps(1000, 0) == 0.0
    assert metrics.packets_per_second(50, 10) == pytest.approx(5.0)
    assert metrics.packet_delivery_ratio(75, 100) == pytest.approx(75.0)
    assert metrics.packet_loss_percent(100, 75) == pytest.approx(25.0)
    assert metrics.packet_delivery_ratio(0, 0) == 0.0
    assert metrics.packet_loss_percent(0, 0) == 0.0
    assert metrics.average_delay(0.6, 3) == pytest.approx(0.2)
    assert metrics.average_delay(1.0, 0) == 0.0
    # loss and PDR are complementary
    assert metrics.packet_loss_percent(40, 31) + metrics.packet_delivery_ratio(31, 40) == pytest.approx(100.0)


def test_formatters():
    assert metrics.format_bytes(512) == "512 B"
    assert metrics.format_bytes(2048) == "2.00 KB"
    assert metrics.format_bps(1_500_000) == "1.50 Mbps"


def test_dataset_metrics():
    m = metrics.dataset_metrics(100, 50_000, 10.0, 20.0)
    assert m["duration_s"] == pytest.approx(10.0)
    assert m["throughput_bps"] == pytest.approx(40_000.0)
    assert m["packets_per_second"] == pytest.approx(10.0)
    assert m["avg_packet_size"] == pytest.approx(500.0)
    empty = metrics.dataset_metrics(0, 0, None, None)
    assert empty["throughput_bps"] == 0.0


def test_trace_analysis_known_values(trace_file):
    result = trace_parser.analyze_trace(trace_file)
    o = result["overall"]
    assert o["packets_sent"] == 4
    assert o["packets_received"] == 3
    assert o["packets_dropped"] == 1
    assert o["loss_percent"] == pytest.approx(25.0)
    assert o["pdr_percent"] == pytest.approx(75.0)
    assert o["avg_delay_s"] == pytest.approx(0.2)
    assert o["bytes_received"] == 3000
    assert o["interval_s"] == pytest.approx(4.1 - 1.0)
    assert o["throughput_bps"] == pytest.approx(3000 * 8 / 3.1)
    assert len(result["flows"]) == 1 and result["flows"][0]["flow_id"] == 1


def test_timeseries_conserves_bytes(trace_file):
    series = trace_parser.load_timeseries(trace_file, bin_s=1.0, aggregate=True)
    total_bits = (series["throughput_kbps"] * 1000 * 1.0).sum()
    assert total_bits == pytest.approx(3000 * 8)
    per_flow = trace_parser.load_timeseries(trace_file, bin_s=1.0)
    assert set(per_flow["flow"]) == {"Flow 1"}


def test_bad_traces(tmp_path):
    with pytest.raises(trace_parser.TraceParseError):
        trace_parser.parse_trace(tmp_path / "missing.tr")
    empty = tmp_path / "empty.tr"
    empty.write_text("")
    with pytest.raises(trace_parser.TraceParseError):
        trace_parser.parse_trace(empty)
    junk = tmp_path / "junk.tr"
    junk.write_text("hello world this is not a trace\n")
    with pytest.raises(trace_parser.TraceParseError):
        trace_parser.parse_trace(junk)
    acks_only = tmp_path / "acks.tr"
    acks_only.write_text("+ 1.0 3 1 ack 40 ------- 1 3.0 0.0 0 1\n")
    with pytest.raises(trace_parser.TraceParseError):
        trace_parser.analyze_trace(acks_only)


@pytest.mark.skipif(shutil.which("awk") is None, reason="awk not installed")
def test_awk_matches_pandas(trace_file):
    awk = trace_parser.awk_summary(trace_file)
    assert awk["sent"] == 4 and awk["received"] == 3 and awk["dropped"] == 1
    assert awk["avg_delay"] == pytest.approx(0.2)
    overall = trace_parser.analyze_trace(trace_file)["overall"]
    assert trace_parser.awk_matches(overall, awk) is True
