from pathlib import Path

import pytest
from scapy.layers.dns import DNS, DNSQR
from scapy.layers.inet import ICMP, IP, TCP, UDP
from scapy.layers.inet6 import IPv6
from scapy.layers.l2 import ARP, Ether
from scapy.packet import Raw
from scapy.utils import PcapNgWriter

from capture.dataset_reader import (
    InvalidCaptureError,
    count_packets,
    detect_format,
    get_dataset_info,
    iter_packets,
    save_uploaded_file,
)
from capture.packet_parser import parse_packet
from tools.make_sample_pcap import make_sample_packets, make_sample_pcap


def _parse(pkt, number=1):
    pkt.time = 1_700_000_000.5
    return parse_packet(pkt, number)


def test_tcp_fields_and_flags():
    rec = _parse(Ether() / IP(src="10.0.0.1", dst="10.0.0.2") / TCP(sport=40000, dport=22, flags="S"), 7)
    assert rec["number"] == 7
    assert rec["src_ip"] == "10.0.0.1" and rec["dst_ip"] == "10.0.0.2"
    assert (rec["src_port"], rec["dst_port"]) == (40000, 22)
    assert rec["protocol"] == "TCP"
    assert rec["tcp_flags"] == "S"
    assert rec["timestamp"] == pytest.approx(1_700_000_000.5)
    assert rec["length"] > 40


def test_http_detected_by_payload_and_port():
    http = _parse(Ether() / IP() / TCP(dport=8081) / Raw(b"GET / HTTP/1.1\r\n\r\n"))
    assert http["protocol"] == "HTTP"
    by_port = _parse(Ether() / IP() / TCP(dport=80, flags="S"))
    assert by_port["protocol"] == "HTTP"


def test_tls_detected_by_record_header_and_port():
    hello = _parse(Ether() / IP() / TCP(dport=9443) / Raw(b"\x16\x03\x01\x00\x30abcd"))
    assert hello["protocol"] == "HTTPS/TLS"
    by_port = _parse(Ether() / IP() / TCP(dport=443, flags="S"))
    assert by_port["protocol"] == "HTTPS/TLS"
    assert by_port["tcp_flags"] == "S"


def test_dns_udp_icmp_other():
    dns = _parse(Ether() / IP() / UDP(sport=5555, dport=53) / DNS(rd=1, qd=DNSQR(qname="a.com")))
    assert dns["protocol"] == "DNS" and dns["dst_port"] == 53
    udp = _parse(Ether() / IP() / UDP(sport=5555, dport=9999) / Raw(b"x"))
    assert udp["protocol"] == "UDP" and udp["tcp_flags"] is None
    icmp = _parse(Ether() / IP() / ICMP())
    assert icmp["protocol"] == "ICMP" and icmp["src_port"] is None
    arp = _parse(Ether() / ARP(psrc="10.0.0.5", pdst="10.0.0.6"))
    assert arp["protocol"] == "Other"
    assert (arp["src_ip"], arp["dst_ip"]) == ("10.0.0.5", "10.0.0.6")


def test_ipv6_udp():
    rec = _parse(Ether() / IPv6(src="2001:db8::1", dst="2001:db8::2") / UDP(sport=1000, dport=2000))
    assert rec["src_ip"] == "2001:db8::1" and rec["protocol"] == "UDP"


def test_pcap_roundtrip_and_count(tmp_path):
    path = make_sample_pcap(tmp_path / "s.pcap", 120)
    assert detect_format(path) == "pcap"
    assert count_packets(path) == 120
    numbers = [n for n, _ in iter_packets(path)]
    assert numbers == list(range(1, 121))
    info = get_dataset_info(path)
    assert info["packets"] == 120 and info["format"] == "pcap" and info["filename"] == "s.pcap"


def test_pcapng_supported(tmp_path):
    path = tmp_path / "s.pcapng"
    writer = PcapNgWriter(str(path))
    for pkt in make_sample_packets(25):
        writer.write(pkt)
    writer.close()
    assert detect_format(path) == "pcapng"
    assert count_packets(path) == 25
    assert sum(1 for _ in iter_packets(path)) == 25


def test_invalid_files_rejected(tmp_path):
    bad_ext = tmp_path / "x.txt"
    bad_ext.write_bytes(b"hello" * 20)
    with pytest.raises(InvalidCaptureError):
        detect_format(bad_ext)
    fake = tmp_path / "fake.pcap"
    fake.write_bytes(b"this is not a capture file at all, sorry")
    with pytest.raises(InvalidCaptureError):
        detect_format(fake)
    empty = tmp_path / "empty.pcap"
    empty.write_bytes(b"")
    with pytest.raises(InvalidCaptureError):
        detect_format(empty)
    with pytest.raises(InvalidCaptureError):
        detect_format(tmp_path / "missing.pcap")


def test_save_uploaded_file_validates(tmp_path):
    good = make_sample_pcap(tmp_path / "src.pcap", 10).read_bytes()
    saved = save_uploaded_file("../../evil name.pcap", good, dest_dir=tmp_path / "up")
    assert saved.parent == tmp_path / "up" and saved.is_file()
    with pytest.raises(InvalidCaptureError):
        save_uploaded_file("junk.pcap", b"not a pcap, definitely not" * 3, dest_dir=tmp_path / "up")
    assert not (tmp_path / "up" / "junk.pcap").exists()
